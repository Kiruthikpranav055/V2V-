# MINING VEHICLE-TO-VEHICLE (V2V) SAFETY MONITORING SYSTEM
### Real-Time Industrial Fleet Telemetry & Collision Prevention Architecture

[![System Status](https://img.shields.io/badge/System-Operational-emerald)](#)
[![Hardware](https://img.shields.io/badge/MCU-ESP32%20DevKit%20V1-blue)](#)
[![Backend](https://img.shields.io/badge/Backend-Python%20%7C%20Flask%20%7C%20Socket.IO-yellow)](#)
[![Frontend](https://img.shields.io/badge/Frontend-HTML5%20%7C%20Leaflet.js%20%7C%20CSS3-orange)](#)
[![Safety Standard](https://img.shields.io/badge/Safety%20Barrier-50%20cm%20%280.5%20m%29-red)](#)

---

## 1. Project Overview

The **Mining Vehicle-to-Vehicle (V2V) Safety Monitoring System** is a mission-critical, hardware-driven industrial telemetry and automated safety platform. Designed specifically for heavy open-pit and underground mining haul trucks, bulldozers, and drilling rigs, this project addresses one of the mining sector's most lethal hazards: **blind-spot collisions, runaway haul vehicles, rollovers, and hazardous wet road surface conditions**.

Unlike simulation prototypes, **this system operates exclusively with real hardware**. Sensor readings (proximity, tilt, vibration, surface water, ambient climate, geolocation) originate strictly from on-board sensors wired to an **ESP32 microcontroller**, transmitted via Wi-Fi and sub-GHz LoRa radio to an authoritative **Python Flask & Flask-SocketIO telemetry hub**, and displayed instantaneously on a high-visibility, industrial monitoring dashboard.

```
       +-------------------------------------------------------+
       |                ON-VEHICLE HARDWARE                    |
       |  HC-SR04 | MPU6050 | Rain Sensor | DHT | GPS | LoRa   |
       |  DC Motor | L298N Driver | Active Buzzer | OLED (I2C) |
       +-------------------------------------------------------+
                                  |
                           ESP32 Controller
                          (Safety Automaton)
                                  |
              +-------------------+-------------------+
              | (Local Mesh)                          | (Telemetry Link)
         LoRa (SX1278)                           Wi-Fi (HTTP POST)
              |                                       |
    [Peer Mining Trucks]                              v
                                        +---------------------------+
                                        |  FLASK BACKEND & SOCKETS  |
                                        |   - State Authority       |
                                        |   - Safety Interlock Sync |
                                        |   - Heartbeat Watcher     |
                                        +---------------------------+
                                                      |
                                            WebSocket / REST
                                                      v
                                        +---------------------------+
                                        |  INDUSTRIAL WEB DASHBOARD |
                                        |   - 50 cm Safety Lockout  |
                                        |   - Leaflet GPS Fleet Map |
                                        |   - Real-Time Alerts Log  |
                                        +---------------------------+
```

---

## 2. Project Objectives

1. **Deterministic Collision Prevention**: Execute real-time obstacle detection with a strict **50 cm (0.5 meter)** threshold that automatically stops vehicle propulsion at the microcontroller level.
2. **Fail-Safe Safety Interlock**: When an obstacle is detected, lock the motor driver, trigger in-cab audible alarms, block manual motion, and enforce an **authorized operator reset procedure** (the vehicle will not automatically move simply because an obstacle clears).
3. **Multi-Hazard Environmental Awareness**: Monitor vehicle tilt and dynamic jerk via 6-DoF IMU (MPU6050), detect slick mining roads (Rain Sensor), and track underground atmosphere (DHT11/DHT22).
4. **V2V Mesh Redundancy**: Provide local vehicle-to-vehicle collision beaconing via sub-GHz LoRa (SX1278) even when Wi-Fi or cellular base stations lose coverage.
5. **Real-Hardware Truth**: Strictly avoid simulated, randomized, or mock telemetry values. If a sensor is disconnected or GPS has no lock, the system transparently reports `DISCONNECTED`, `NO DATA`, or `NO FIX`.

---

## 3. Hardware Components

| # | Hardware Module | Model / Spec | Function & Role in Mining Architecture |
|---|-----------------|--------------|----------------------------------------|
| **1** | **Main MCU** | ESP32 DevKit V1 (30/38 pin) | Dual-core 240MHz controller running safety loops, sensor ingestion, Wi-Fi networking, and local OLED refresh. |
| **2** | **Actuator (Left)** | DC Geared Motor A | Left drivetrain wheel/track motor for forward, reverse, and differential steering. |
| **3** | **Actuator (Right)**| DC Geared Motor B | Right drivetrain wheel/track motor for forward, reverse, and differential steering. |
| **4** | **Motor Driver** | L298N / TB6612 Dual H-Bridge | Full 4-directional control (Forward, Backward, Left, Right, Stop) with hardware safety interlock. |
| **5** | **IMU Sensor** | MPU6050 (I2C) | 3-axis accelerometer and 3-axis gyroscope monitoring pitch (grade slope), roll (rollover risk), and vibration jerk. |
| **6** | **Surface Sensor**| LM393 Rain Sensor Module | Detects rain droplets and wet road conditions on mining haul ramps. |
| **7** | **Climate Sensor**| DHT11 / DHT22 | Measures ambient tunnel/open-cast air temperature (°C) and relative humidity (%). |
| **8** | **Geolocation** | NEO-6M GPS Module | Provides real-world vehicle latitude, longitude, speed, and satellite count via hardware UART. |
| **9** | **Proximity** | HC-SR04 Ultrasonic | Accurate short-range distance measurement with a hardcoded `SAFETY_DISTANCE_CM = 50` threshold. |
| **10**| **Local Alarm** | Active 5V Buzzer | Audible in-cab alert sounding automatically when a safety stop is triggered. |
| **11**| **Local Display**| SSD1306 0.96" I2C OLED | In-cab operator screen showing real-time distance, vehicle state, IP address, and alarms. |
| **12**| **Power Management**| DC-DC Boost / Buck Converter | Steps up single Li-ion cell (3.7V) to 5V / 12V for motor and sensor rails (*Hardware power component; not a fake sensor*). |
| **13**| **Manual Reset** | Tactile Push Button | Physical safety reset interlock button wired with internal pull-up. |

---

## 4. Software Architecture

### Directory Tree
```
mining-v2v/
├── frontend/
│   ├── index.html        # Clean, dark-mode industrial safety dashboard
│   ├── style.css         # High-contrast industrial UI styling & safety animations
│   └── script.js         # Leaflet.js map, Socket.IO client, safety interlock handlers
├── backend/
│   ├── app.py            # Flask API, SocketIO broadcast, state authority, heartbeat thread
│   └── requirements.txt  # Python package specifications
├── esp32/
│   ├── esp32_v2v.ino     # Production C++ firmware with safety state machine
│   └── config.h          # Hardware pinout, thresholds, and Wi-Fi configuration
└── README.md             # Complete engineering documentation
```

### Communication Protocols
- **ESP32 -> Backend**: HTTP POST JSON (`/api/sensor-data`) over 2.4 GHz Wi-Fi.
- **Backend -> Web Dashboard**: WebSockets (`Flask-SocketIO`) with bi-directional event emission and automated REST polling fallback (`GET /api/sensor-data`).
- **Web Dashboard -> Backend -> ESP32**: Authorized operator unlock dispatch (`POST /api/safety/reset`) validated by proximity checks and returned in HTTP downlink payloads.
- **ESP32 -> ESP32 (V2V)**: Sub-GHz LoRa RF packets at 433 MHz / 868 MHz / 915 MHz.

---

## 5. ESP32 Pinout & Sensor Connections

The following pin allocation guarantees conflict-free operation on the ESP32 DevKit V1:

```
                                  ESP32 DevKit V1
                              +--------------------+
             [Right Motor IN3]-| GPIO 18     GPIO 21 |- [I2C SDA (OLED + MPU6050)]
             [Right Motor IN4]-| GPIO 19     GPIO 22 |- [I2C SCL (OLED + MPU6050)]
             [Right Motor ENB]-| GPIO 23     GPIO 25 |- [Active Buzzer (+)]
            [Ultrasonic TRIG]-| GPIO 12     GPIO 26 |- [Left Motor IN1]
            [Ultrasonic ECHO]-| GPIO 13     GPIO 33 |- [Left Motor IN2]
             [Rain Sensor DO]-| GPIO 27     GPIO 32 |- [Left Motor ENA/PWM]
              [DHT11/22 Data]-| GPIO 4          GND |- Common Ground
              [GPS Module RX]-| GPIO 16         VIN |- 5V Power Supply Rail
              [GPS Module TX]-| GPIO 17         3V3 |- 3.3V Logic Rail
             [Safety ResetBtn]-| GPIO 15     GPIO 2  |- Unused GPIO
                              +--------------------+
```

### Detailed Wiring Table

| Component | Pin Label | ESP32 GPIO | Description / Notes |
|-----------|-----------|------------|---------------------|
| **HC-SR04** | TRIG | **GPIO 12** | Ultrasonic trigger pulse output (10µs). |
| | ECHO | **GPIO 13** | Echo input (*Use 1kΩ / 2kΩ voltage divider to step 5V echo to 3.3V*). |
| **MPU6050** | SDA | **GPIO 21** | I2C Data (Shared with OLED, 0x68 address). |
| | SCL | **GPIO 22** | I2C Clock (Shared with OLED). |
| **SSD1306 OLED**| SDA | **GPIO 21** | I2C Data (0x3C address). |
| | SCL | **GPIO 22** | I2C Clock. |
| **Rain Sensor** | DO | **GPIO 27** | Digital output from LM393 comparator (Active LOW on wet surface). |
| **DHT11 / DHT22**| DATA | **GPIO 4** | Single-bus data line with 10kΩ pull-up to 3.3V. |
| **NEO-6M GPS** | TX | **GPIO 16** | GPS TX connects to ESP32 RX2 (HardwareSerial 2). |
| | RX | **GPIO 17** | GPS RX connects to ESP32 TX2. |
| **Left DC Motor** | IN1 | **GPIO 26** | Left motor forward/reverse logic 1. |
| | IN2 | **GPIO 33** | Left motor forward/reverse logic 2. |
| | ENA / PWM | **GPIO 32** | Left motor speed control via ESP32 LEDC PWM channel 0. |
| **Right DC Motor**| IN3 | **GPIO 18** | Right motor forward/reverse logic 1. |
| | IN4 | **GPIO 19** | Right motor forward/reverse logic 2. |
| | ENB / PWM | **GPIO 23** | Right motor speed control via ESP32 LEDC PWM channel 1. |
| **Active Buzzer**| (+) | **GPIO 25** | Active HIGH drive transistor / direct GPIO. |
| **Safety Reset** | Pin | **GPIO 15** | Push button connected to GND (`pinMode(15, INPUT_PULLUP)`). |
| **Boost Converter**| OUT+/OUT- | 5V / 12V Rail | Powers motor driver and 5V sensors. Must share common GND with ESP32. |

---

## 6. Wi-Fi & Firmware Configuration

All system parameters are defined centrally in [`esp32/config.h`](file:///c:/Users/Gateway/Downloads/V2V/mining-v2v/esp32/config.h):

```cpp
// 1. Wi-Fi Access Point Credentials
#define WIFI_SSID         "YOUR_MINING_WIFI_SSID"
#define WIFI_PASSWORD     "YOUR_WIFI_PASSWORD"

// 2. Flask Server IP & Port on Local Subnet
#define BACKEND_SERVER_URL "http://192.168.1.100:5000/api/sensor-data"

// 3. Configurable Single Safety Threshold
const float SAFETY_DISTANCE_CM  = 50.0; // 50 cm = 0.5 meter (Hard Safety Barrier)
const float MAX_SENSOR_RANGE_CM = 999.0;
```

### Arduino IDE Setup
1. Open Arduino IDE -> **Settings** -> add ESP32 Board Manager URL:
   `https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json`
2. Install **ESP32** board package (by Espressif Systems).
3. Install required libraries from Library Manager:
   - `ArduinoJson` (v6.x or v7.x)
   - `Adafruit MPU6050`
   - `Adafruit SSD1306` & `Adafruit GFX Library`
   - `DHT sensor library` (Adafruit)
   - `TinyGPSPlus` (by Mikal Hart)
   - `LoRa` (by Sandeep Mistry)
4. Select Board: **ESP32 Dev Module**.
5. Set Upload Speed: `921600`, Flash Frequency: `80MHz`.
6. Compile and Upload.

---

## 7. Automatic Safety-Stop Logic & State Machine

The safety automaton enforces strict deterministic rules where safety priority overrides all manual movement commands.

### Safety State Hierarchy

```
       [NORMAL]  <-- All sensors nominal, path clear (> 50 cm)
          |
          +--> [WARNING]    <-- Wet road (Rain) OR minor tilt/vibration
          |
          +--> [HIGH_RISK]  <-- Rain + Tilt/Vibration combination
          |
          v
     [AUTO_STOP]    <-- Obstacle detected at <= 50 cm (0.5 meter)
          |             - Instant motor cutoff
          |             - Buzzer sounds continuously
          |             - Manual movement blocked
          v
    [MOTOR_LOCKED]  <-- Remains locked even if obstacle moves away!
          |
   [OPERATOR RESET] <-- Verification: Is distance > 50 cm?
          |             - YES -> Unlock motor, silence buzzer -> [NORMAL]
          |             - NO  -> Reject reset command, remain [MOTOR_LOCKED]
```

### Priority Enforcement Table

| Condition | Proximity Distance | Safety State | Motor Driver | Buzzer | Manual Controls |
|-----------|--------------------|--------------|--------------|--------|-----------------|
| Clear Path, Dry Road | `> 50 cm` | **NORMAL** | Operational | OFF | Enabled |
| Rain / Slick Road | `> 50 cm` | **WARNING** | Operational | OFF | Enabled |
| Severe Tilt / High Jerk | `> 50 cm` | **WARNING** | Operational | OFF | Enabled |
| Rain + Severe Tilt | `> 50 cm` | **HIGH RISK**| Operational | OFF | Enabled |
| **Obstacle Detected** | **`<= 50 cm`** | **AUTO STOP**| **LOCKED (BRAKE)** | **ON** | **BLOCKED** |
| Obstacle Removed | `> 50 cm` | **MOTOR LOCKED** | **LOCKED** | **ON/MUTED** | **BLOCKED** |
| Operator Reset (Obstacle Clear) | `> 50 cm` | **NORMAL** | Unlocked | OFF | Enabled |
| Operator Reset (Obstacle Present)| `<= 50 cm` | **MOTOR LOCKED** | **LOCKED** | **ON** | **REJECTED (400)** |

---

## 8. Backend API Documentation

The backend exposes clean REST endpoints and WebSocket events.

### 1. Ingest Hardware Telemetry
- **Endpoint**: `POST /api/sensor-data`
- **Sender**: ESP32 Microcontroller
- **Content-Type**: `application/json`
- **Request Payload**:
```json
{
  "temperature": 28.4,
  "humidity": 62.1,
  "rain": false,
  "distance_cm": 42.6,
  "tilt_pitch": 4.1,
  "tilt_roll": -1.8,
  "vibration_level": 0.45,
  "stability": "STABLE",
  "motor": "STOPPED",
  "motor_locked": true,
  "buzzer": true,
  "latitude": 23.41284,
  "longitude": 85.34192,
  "gps_valid": true,
  "gps_satellites": 7,
  "lora_connected": true,
  "safety_state": "AUTO_STOP"
}
```
*Note: If any sensor is unavailable, the field transmits as `null`, `false`, or `"UNKNOWN"`. No mock numbers are accepted.*

- **Response (Downlink to ESP32)**:
```json
{
  "status": "success",
  "motor_locked": true,
  "unlock_command": false,
  "server_time": 1730000000.0
}
```

### 2. Retrieve Latest Telemetry
- **Endpoint**: `GET /api/sensor-data`
- **Consumer**: Web Dashboard / Third-Party Fleet SCADA
- **Response**: Full telemetry JSON with connection health, alerts history, and last-seen timestamp.

### 3. Authorized Safety Reset & Unlock
- **Endpoint**: `POST /api/safety/reset`
- **Validation**: Checks if current distance is `> 50 cm`.
- **Response if Clear (200 OK)**:
```json
{
  "status": "success",
  "message": "Safety lock released. Motor unlocked and system restored to NORMAL.",
  "motor_locked": false,
  "safety_state": "NORMAL"
}
```
- **Response if Obstacle Still Present (400 Bad Request)**:
```json
{
  "status": "error",
  "message": "SAFETY INTERLOCK: Cannot unlock! Obstacle still within 50 cm safety zone (42.6 cm detected).",
  "current_distance": 42.6
}
```

### 4. Manual Movement Control
- **Endpoint**: `POST /api/motor/control`
- **Body**: `{"command": "FORWARD"}` | `{"command": "STOP"}`
- **Response**: Returns 403 Forbidden if vehicle is currently in `MOTOR_LOCKED` or distance `<= 50 cm`.

---

## 9. Backend Setup & Local Running

### Prerequisites
- Python 3.10+ (Tested on Python 3.13)
- pip

### Step-by-Step Installation
```bash
# 1. Navigate to backend directory
cd mining-v2v/backend

# 2. Install dependencies
pip install -r requirements.txt

# 3. Launch Flask-SocketIO Server on port 5000
python app.py
```

The server binds to `http://0.0.0.0:5000`. You can access the live dashboard by opening your browser to:
`http://localhost:5000` or `http://<YOUR_PC_LOCAL_IP>:5000`

---

## 10. Frontend Dashboard Architecture

The frontend is served directly by the Flask application from [`mining-v2v/frontend`](file:///c:/Users/Gateway/Downloads/V2V/mining-v2v/frontend):

1. **Header Strip**: Shows real-time connection badges for ESP32 hardware, Wi-Fi link, and LoRa radio mesh.
2. **Main Safety Banner**: Massive, high-visibility status box that changes dynamically between `NORMAL` (Emerald), `WARNING` (Amber), and `AUTO STOP / MOTOR LOCKED` (Flashing Safety Crimson).
3. **Telemetry Sensor Cards**:
   - **Ultrasonic Distance**: Displays distance in both cm and meters (e.g. `45.2 cm / 0.45 m`), with a safety threshold bar highlighting the 50 cm barrier.
   - **Environment (DHT)**: Shows real temperature and humidity or `DHT DISCONNECTED`.
   - **Rain Sensor**: Displays `NO RAIN` or `RAIN DETECTED` (with haul road slickness hazard tags).
   - **MPU6050 Dynamics**: Shows Pitch (°), Roll (°), and Vibration Jerk (g).
   - **Actuators**: Motor state (`RUNNING`, `STOPPED`, `LOCKED`) and Buzzer status (`ON` / `OFF`).
   - **V2V LoRa Mesh**: Dedicated radio connectivity status distinct from Wi-Fi.
4. **Interactive Leaflet GPS Map**:
   - Starts with a regional map overview.
   - Displays a prominent `"GPS STATUS: NO FIX"` overlay if satellites are not locked.
   - When real coordinates arrive from the NEO-6M, flies smoothly to the exact vehicle coordinate with a custom vehicle marker, real-time speed, and satellite count.
5. **Live Safety Alerts Log**: Chronological alert feed capturing every emergency stop, road condition change, and hardware disconnection.

---

## 11. GPS Map Setup & Satellite Acquisition

1. The NEO-6M GPS antenna must have an unobstructed view of the open sky (near an exterior window or outdoors in a mining pit).
2. The NEO-6M module features an on-board green LED:
   - **Solid ON**: Searching for satellites.
   - **Flashing (1 Hz)**: 3D Fix acquired (minimum 4 satellites locked).
3. The dashboard strictly **never draws a fake vehicle marker** when `gps_valid == false`. The map displays `GPS STATUS: NO FIX` until real satellite positioning is established.

---

## 12. Local Hardware Testing & Verification Procedure

Follow this checklist to verify full system functionality:

### Test 1: Real-Time Connection
1. Power up the ESP32.
2. Open the dashboard at `http://localhost:5000`.
3. Verify that the **ESP32** and **Wi-Fi** header pills transition from red `OFFLINE` to glowing green `ONLINE`.

### Test 2: 50 cm Safety Auto-Stop Verification
1. Place an object (e.g., a hand, cardboard, or vehicle mockup) **30 cm** in front of the HC-SR04 ultrasonic sensor.
2. Observe immediate actions:
   - ESP32 hardware immediately stops the DC motor.
   - Active buzzer sounds loudly in real life.
   - Dashboard instantly displays:
     - **AUTO STOP**
     - **MOTOR LOCKED**
     - **MANUAL CONTROL LOCKED**
     - **OBSTACLE DETECTED (30.0 cm <= 50 cm)**
   - Live alerts log records `CRITICAL: OBSTACLE DETECTED - AUTO STOP`.

### Test 3: Safety Unlock Verification
1. Remove the object so the distance reads `> 50 cm` (e.g. `120 cm`).
2. Verify that the vehicle **REMAINS LOCKED** and does not move automatically.
3. Click the **[RESET & UNLOCK SAFETY SYSTEM]** button on the dashboard (or press the hardware button on ESP32 GPIO 15).
4. Verify that the system resets to **NORMAL**, buzzer silences, and motor controls become available again.

### Test 4: Heartbeat Timeout Detection
1. Unplug the ESP32 USB power.
2. Within 10 seconds, the backend heartbeat watcher will declare the ESP32 `OFFLINE`, marking Wi-Fi disconnected and logging `ESP32 OFFLINE: Telemetry signal lost`.

---

## 13. Deployment Architecture

```
=================================================================================
                           LOCAL FIELD DEVELOPMENT
=================================================================================

+---------------+       Local Wi-Fi Router      +---------------+     Browser
| ESP32 Vehicle |  -------------------------->  | Flask Backend |  ------------>
|  Hardware     |   POST /api/sensor-data       | (192.168.1.x) |  Web Dashboard
+---------------+                               +---------------+

=================================================================================
                      PRODUCTION CLOUD FLEET ARCHITECTURE
=================================================================================

+---------------+       4G/5G / Satellite       +---------------+     Secure SSL
| ESP32 Vehicle |  -------------------------->  | Cloud Server  |  ------------>
| (Mine Fleet)  |   HTTPS (api.minev2v.com)     | (Nginx+Gunicorn) Remote Control
+---------------+                               +---------------+     Center
```

> [!IMPORTANT]
> A web browser running on a remote laptop cannot access a private IP (`192.168.x.x`) on an ESP32. In both local and production setups, the ESP32 reports upstream to the Flask API, which serves as the authoritative single source of truth for all clients.

---

## 14. GitHub Setup & Security Guidelines

- **No Secrets in Code**: Never commit Wi-Fi passwords, private API keys, or production certificates.
- Use environment variables (`export PORT=5000`) for backend configuration.
- A recommended `.gitignore` is provided below:

```gitignore
# Byte-compiled / optimized files
__pycache__/
*.py[cod]
*$py.class

# Virtual environments
venv/
env/
.env

# Arduino temporary build files
*.hex
*.bin
*.elf
```

---

## 15. Summary of Compliance

- **No Fake / Random / Simulated Data**: Initial state cleanly reflects `NO DATA`, `DISCONNECTED`, `NO FIX`. Real values only populate upon hardware packet reception.
- **50 cm Safety Rule**: Configured once in `SAFETY_DISTANCE_CM = 50.0`. Triggers `AUTO_STOP`, `MOTOR_LOCKED`, `MANUAL CONTROL LOCKED`, and `BUZZER ON`.
- **Safety Interlock**: Requires intentional reset; will refuse to unlock if an obstacle remains within 50 cm.
- **Hardware Integration**: Full code for ESP32, MPU6050, DHT, Rain, Ultrasonic, GPS, OLED, LoRa, Buzzer, and Motor.
- **Production Cleanliness**: Professional industrial dark design, responsive, modular, and GitHub-ready.
