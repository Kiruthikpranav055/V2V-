"""
Mining Vehicle-to-Vehicle (V2V) Safety Monitoring System
Backend API & Real-Time Telemetry Hub
Technology: Python, Flask, Flask-SocketIO, REST API
"""

import os
import time
import logging
from datetime import datetime
from threading import Thread, RLock
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from flask_socketio import SocketIO, emit

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
logger = logging.getLogger("MiningV2V")

# Resolve directories
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(BASE_DIR, "..", "frontend")

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="")
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

# Re-entrant thread lock for synchronized state mutations
state_lock = RLock()

# Configurable Safety Distance Threshold (in centimeters)
SAFETY_DISTANCE_CM = 50.0  # 50 cm = 0.5 meter (Hard Safety Barrier)
HEARTBEAT_TIMEOUT_SEC = 10.0  # Time before ESP32 is declared OFFLINE

# Authoritative State Store (Starts clean with NO FAKE DATA)
telemetry_state = {
    # System & Connectivity
    "online": False,
    "last_seen_timestamp": None,
    "last_seen_readable": "NEVER",
    "ip_address": None,
    "packet_count": 0,
    "wifi_connected": False,

    # Vehicle Overall Safety State: NORMAL | WARNING | HIGH_RISK | AUTO_STOP | MOTOR_LOCKED
    "safety_state": "NORMAL",
    "safety_distance_cm": SAFETY_DISTANCE_CM,

    # Environmental Sensors
    "temperature": None,
    "humidity": None,
    "dht_connected": False,
    "rain": False,
    "rain_status": "NO DATA",

    # Proximity & Obstacle Detection
    "distance_cm": None,
    "distance_status": "NO DATA",
    "obstacle_detected": False,

    # Dynamics & Inertial (MPU6050)
    "tilt_pitch": None,
    "tilt_roll": None,
    "vibration_level": None,
    "stability": "UNKNOWN",
    "mpu_connected": False,

    # Actuators (Full Directional D-Pad Controls)
    "motor": "STOPPED",
    "motor_command": "STOP",  # FORWARD | BACKWARD | LEFT | RIGHT | STOP
    "motor_locked": False,
    "manual_control_locked": False,
    "buzzer": False,

    # GPS Geolocation
    "latitude": None,
    "longitude": None,
    "altitude_m": None,
    "speed_kmh": None,
    "gps_valid": False,
    "gps_satellites": 0,
    "gps_status": "NO FIX",

    # Downlink Flag for Hardware Unlock Sync
    "pending_unlock_request": False
}

# Live Alerts Storage (Max 100 recent alerts)
alerts_history = []
alert_id_counter = 0

def add_alert(title, message, severity="INFO"):
    """
    Append an alert to the circular history and broadcast via WebSocket.
    Severities: INFO, WARNING, DANGER, CRITICAL
    """
    global alert_id_counter
    with state_lock:
        alert_id_counter += 1
        alert = {
            "id": alert_id_counter,
            "timestamp": datetime.now().strftime("%H:%M:%S"),
            "iso_time": datetime.now().isoformat(),
            "title": title,
            "message": message,
            "severity": severity
        }
        # Keep maximum 100 alerts
        alerts_history.insert(0, alert)
        if len(alerts_history) > 100:
            alerts_history.pop()

    logger.warning(f"ALERT [{severity}] - {title}: {message}")
    socketio.emit("new_alert", alert)
    return alert


# ==============================================================================
# STATIC FRONTEND ROUTES
# ==============================================================================
@app.route("/")
def serve_index():
    """Serve Dashboard Homepage."""
    return send_from_directory(FRONTEND_DIR, "index.html")

@app.route("/<path:path>")
def serve_static(path):
    """Serve Frontend Static Assets (CSS, JS, Icons)."""
    return send_from_directory(FRONTEND_DIR, path)


# ==============================================================================
# REST API ENDPOINTS
# ==============================================================================
@app.route("/api/sensor-data", methods=["GET"])
def get_sensor_data():
    """
    GET /api/sensor-data
    Return authoritative vehicle safety state and telemetry for the web dashboard.
    """
    with state_lock:
        return jsonify({
            "status": "success",
            "telemetry": telemetry_state,
            "alerts": alerts_history[:15],
            "server_time": time.time()
        }), 200


@app.route("/api/sensor-data", methods=["POST"])
def post_sensor_data():
    """
    POST /api/sensor-data
    Ingest REAL sensor telemetry directly from ESP32 via Wi-Fi.
    Enforces hardware safety automaton rules and synchronizes lock state.
    """
    if not request.is_json:
        return jsonify({"status": "error", "message": "Content-Type must be application/json"}), 400

    payload = request.get_json()
    now = time.time()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    client_ip = request.remote_addr

    with state_lock:
        # Mark ESP32 and Wi-Fi Online
        was_offline = not telemetry_state["online"]
        telemetry_state["online"] = True
        telemetry_state["wifi_connected"] = True
        telemetry_state["last_seen_timestamp"] = now
        telemetry_state["last_seen_readable"] = now_str
        telemetry_state["ip_address"] = client_ip
        telemetry_state["packet_count"] += 1

        if was_offline:
            add_alert("ESP32 CONNECTED", f"Real-time telemetry link established from {client_ip}", "INFO")

        # Parse Environmental Sensors (DHT)
        temp = payload.get("temperature")
        hum = payload.get("humidity")
        if temp is not None and hum is not None:
            telemetry_state["temperature"] = round(float(temp), 1)
            telemetry_state["humidity"] = round(float(hum), 1)
            telemetry_state["dht_connected"] = True
        else:
            telemetry_state["temperature"] = None
            telemetry_state["humidity"] = None
            telemetry_state["dht_connected"] = False

        # Parse Rain Sensor
        rain_val = payload.get("rain")
        if rain_val is not None:
            telemetry_state["rain"] = bool(rain_val)
            prev_rain = telemetry_state.get("rain_status")
            telemetry_state["rain_status"] = "RAIN DETECTED" if telemetry_state["rain"] else "NO RAIN"
            if telemetry_state["rain"] and prev_rain != "RAIN DETECTED":
                add_alert("RAIN DETECTED", "Wet road condition detected. Mining haul roads slick.", "WARNING")
        else:
            telemetry_state["rain"] = False
            telemetry_state["rain_status"] = "NO DATA"

        # Parse MPU6050 Stability & Tilt
        mpu_conn = payload.get("mpu_connected", True)
        telemetry_state["mpu_connected"] = bool(mpu_conn)
        pitch = payload.get("tilt_pitch", payload.get("tilt"))
        roll = payload.get("tilt_roll")
        vib = payload.get("vibration_level")

        if pitch is not None:
            telemetry_state["tilt_pitch"] = round(float(pitch), 1)
        if roll is not None:
            telemetry_state["tilt_roll"] = round(float(roll), 1)
        if vib is not None:
            telemetry_state["vibration_level"] = round(float(vib), 2)

        stability_in = payload.get("stability", "UNKNOWN")
        telemetry_state["stability"] = str(stability_in).upper()

        if telemetry_state["stability"] in ["TILT_DETECTED", "HIGH_VIBRATION", "UNSTABLE"]:
            add_alert("INSTABILITY DETECTED", f"Vehicle dynamics warning: {telemetry_state['stability']}", "WARNING")

        # Parse GPS
        gps_val = payload.get("gps_valid", False)
        lat = payload.get("latitude")
        lng = payload.get("longitude")
        if gps_val and lat is not None and lng is not None:
            telemetry_state["gps_valid"] = True
            telemetry_state["latitude"] = float(lat)
            telemetry_state["longitude"] = float(lng)
            telemetry_state["altitude_m"] = payload.get("altitude_m")
            telemetry_state["speed_kmh"] = payload.get("speed_kmh", 0.0)
            telemetry_state["gps_satellites"] = payload.get("gps_satellites", 0)
            telemetry_state["gps_status"] = "3D FIX"
        else:
            telemetry_state["gps_valid"] = False
            telemetry_state["latitude"] = None
            telemetry_state["longitude"] = None
            telemetry_state["gps_status"] = "NO FIX"

        # ======================================================================
        # AUTOMATIC SAFETY STOP LOGIC (Hard Requirement: SAFETY_DISTANCE_CM = 50)
        # ======================================================================
        raw_dist = payload.get("distance_cm")
        if raw_dist is not None:
            try:
                dist_val = float(raw_dist)
                if dist_val > 999.0 or dist_val < 0.0:
                    telemetry_state["distance_cm"] = None
                    telemetry_state["distance_status"] = "OUT OF RANGE"
                    telemetry_state["obstacle_detected"] = False
                else:
                    telemetry_state["distance_cm"] = round(dist_val, 1)
                    telemetry_state["distance_status"] = f"{round(dist_val, 1)} cm"

                    # Check Obstacle Threshold
                    if dist_val <= SAFETY_DISTANCE_CM:
                        telemetry_state["obstacle_detected"] = True
                        telemetry_state["safety_state"] = "AUTO_STOP"
                        telemetry_state["motor_locked"] = True
                        telemetry_state["manual_control_locked"] = True
                        telemetry_state["motor"] = "LOCKED"
                        telemetry_state["buzzer"] = True

                        add_alert(
                            "OBSTACLE DETECTED - AUTO STOP",
                            f"Obstacle at {round(dist_val, 1)} cm (<= {int(SAFETY_DISTANCE_CM)} cm limit). MOTOR LOCKED! Buzzer ON.",
                            "CRITICAL"
                        )
                    else:
                        telemetry_state["obstacle_detected"] = False
                        # NOTE: If vehicle was previously MOTOR_LOCKED, it MUST REMAIN LOCKED
                        # even if distance > 50 cm until intentional reset/unlock is performed!
            except ValueError:
                telemetry_state["distance_cm"] = None
                telemetry_state["distance_status"] = "INVALID"
        else:
            telemetry_state["distance_cm"] = None
            telemetry_state["distance_status"] = "NO DATA"

        # Hardware safety state propagation from ESP32 payload
        esp_state = payload.get("safety_state")
        esp_motor_locked = payload.get("motor_locked")

        if esp_motor_locked is True:
            telemetry_state["motor_locked"] = True
            telemetry_state["manual_control_locked"] = True
            telemetry_state["motor"] = "LOCKED"
            if telemetry_state["safety_state"] == "NORMAL":
                telemetry_state["safety_state"] = "MOTOR_LOCKED"

        if esp_state in ["AUTO_STOP", "MOTOR_LOCKED", "HIGH_RISK", "WARNING"]:
            telemetry_state["safety_state"] = esp_state

        # Determine overall safety state if not locked
        if not telemetry_state["motor_locked"]:
            if telemetry_state["rain"] and (telemetry_state["stability"] != "STABLE"):
                telemetry_state["safety_state"] = "HIGH_RISK"
            elif telemetry_state["rain"] or (telemetry_state["stability"] in ["WARNING", "TILT_DETECTED", "HIGH_VIBRATION"]):
                telemetry_state["safety_state"] = "WARNING"
            else:
                telemetry_state["safety_state"] = "NORMAL"

        # Motor status from hardware if not locked
        if not telemetry_state["motor_locked"]:
            telemetry_state["motor"] = payload.get("motor", "STOPPED")
            telemetry_state["buzzer"] = bool(payload.get("buzzer", False))

        # Check if an authorized unlock request was executed by ESP32
        unlock_downlink = False
        if telemetry_state["pending_unlock_request"]:
            unlock_downlink = True
            telemetry_state["pending_unlock_request"] = False
            logger.info("Transmitting authorized SAFETY UNLOCK downlink command to ESP32.")

    # Broadcast updated telemetry to all web dashboard clients in real-time
    socketio.emit("telemetry_update", telemetry_state)

    # Downlink response back to ESP32
    return jsonify({
        "status": "success",
        "motor_locked": telemetry_state["motor_locked"],
        "motor_command": telemetry_state["motor_command"],
        "unlock_command": unlock_downlink,
        "server_time": now
    }), 200


@app.route("/api/safety/reset", methods=["POST"])
def reset_safety():
    """
    POST /api/safety/reset
    Authorized operator safety reset and motor unlock action.
    STRICT REQUIREMENT: Can only unlock if obstacle is cleared (> 50 cm) or clear.
    """
    with state_lock:
        current_distance = telemetry_state.get("distance_cm")

        # Safety Check: Cannot unlock if obstacle is still <= 50 cm
        if current_distance is not None and current_distance <= SAFETY_DISTANCE_CM:
            error_msg = f"SAFETY INTERLOCK: Cannot unlock! Obstacle still within {int(SAFETY_DISTANCE_CM)} cm safety zone ({current_distance} cm detected)."
            add_alert("UNLOCK REJECTED", error_msg, "CRITICAL")
            return jsonify({
                "status": "error",
                "message": error_msg,
                "current_distance": current_distance
            }), 400

        # Perform Authorized Unlock
        telemetry_state["motor_locked"] = False
        telemetry_state["manual_control_locked"] = False
        telemetry_state["motor"] = "STOPPED"
        telemetry_state["motor_command"] = "STOP"
        telemetry_state["buzzer"] = False
        telemetry_state["safety_state"] = "NORMAL"
        telemetry_state["pending_unlock_request"] = True  # Signal ESP32 on next POST

        add_alert(
            "SAFETY SYSTEM UNLOCKED",
            "Obstacle is clear. Authorized operator reset executed. Motor unlocked. State returned to NORMAL.",
            "INFO"
        )

    socketio.emit("telemetry_update", telemetry_state)

    return jsonify({
        "status": "success",
        "message": "Safety lock released. Motor unlocked and system restored to NORMAL.",
        "safety_state": "NORMAL",
        "motor_locked": False
    }), 200


@app.route("/api/motor/control", methods=["POST"])
def motor_control():
    """
    POST /api/motor/control
    Directional movement dispatcher (FORWARD | BACKWARD | LEFT | RIGHT | STOP).
    SAFETY PRIORITY: Strictly blocked if motor is locked or obstacle <= 50 cm.
    """
    data = request.get_json() or {}
    cmd = str(data.get("command", "STOP")).upper()
    if cmd == "REVERSE":
        cmd = "BACKWARD"

    valid_commands = ["FORWARD", "BACKWARD", "LEFT", "RIGHT", "STOP"]
    if cmd not in valid_commands:
        return jsonify({"status": "error", "message": f"Invalid command: {cmd}"}), 400

    with state_lock:
        # Priority Safety Check
        if cmd != "STOP":
            if telemetry_state["motor_locked"] or telemetry_state["manual_control_locked"]:
                return jsonify({
                    "status": "error",
                    "message": "SAFETY LOCK ACTIVE: Manual motor movement commands are strictly blocked!",
                    "motor_locked": True
                }), 403

            dist = telemetry_state.get("distance_cm")
            if dist is not None and dist <= SAFETY_DISTANCE_CM:
                return jsonify({
                    "status": "error",
                    "message": f"OBSTACLE PROXIMITY HAZARD ({dist} cm <= {int(SAFETY_DISTANCE_CM)} cm): Movement blocked by safety system!",
                    "motor_locked": True
                }), 403

        telemetry_state["motor_command"] = cmd
        telemetry_state["motor"] = cmd

    socketio.emit("telemetry_update", telemetry_state)
    return jsonify({
        "status": "success",
        "motor": telemetry_state["motor"],
        "command": cmd
    }), 200


@app.route("/api/alerts", methods=["GET"])
def get_alerts():
    """GET /api/alerts - Return all historical safety alerts."""
    with state_lock:
        return jsonify({
            "status": "success",
            "alerts": alerts_history
        }), 200


@app.route("/api/alerts", methods=["DELETE"])
def clear_alerts():
    """DELETE /api/alerts - Clear alerts history."""
    with state_lock:
        alerts_history.clear()
    socketio.emit("alerts_cleared", {})
    return jsonify({"status": "success", "message": "Alerts cleared"}), 200


@app.route("/api/health", methods=["GET"])
def health_check():
    """GET /api/health - System diagnostic health endpoint."""
    with state_lock:
        return jsonify({
            "status": "healthy",
            "service": "Mining V2V Telemetry Hub",
            "esp32_online": telemetry_state["online"],
            "packet_count": telemetry_state["packet_count"],
            "timestamp": time.time()
        }), 200


# ==============================================================================
# WEBSOCKET EVENT HANDLERS
# ==============================================================================
@socketio.on("connect")
def handle_connect():
    """On client connection, immediately emit the current authoritative state."""
    logger.info("Web dashboard client connected via WebSocket.")
    with state_lock:
        emit("telemetry_update", telemetry_state)
        emit("initial_alerts", alerts_history[:25])

@socketio.on("disconnect")
def handle_disconnect():
    logger.info("Web dashboard client disconnected.")

@socketio.on("request_state")
def handle_request_state():
    with state_lock:
        emit("telemetry_update", telemetry_state)


@socketio.on("motor_command")
def handle_ws_motor_command(data):
    """Instant low-latency WebSocket directional drive dispatch."""
    cmd = str(data.get("command", "STOP") if isinstance(data, dict) else data).upper()
    if cmd == "REVERSE":
        cmd = "BACKWARD"
    valid_commands = ["FORWARD", "BACKWARD", "LEFT", "RIGHT", "STOP"]
    if cmd not in valid_commands:
        return

    with state_lock:
        if cmd != "STOP":
            if telemetry_state["motor_locked"] or telemetry_state["manual_control_locked"]:
                emit("command_rejected", {"message": "SAFETY LOCK ACTIVE: Motor is locked!"})
                return
            dist = telemetry_state.get("distance_cm")
            if dist is not None and dist <= SAFETY_DISTANCE_CM:
                emit("command_rejected", {"message": f"OBSTACLE DETECTED ({dist} cm <= {int(SAFETY_DISTANCE_CM)} cm)!"})
                return

        telemetry_state["motor_command"] = cmd
        telemetry_state["motor"] = cmd

    socketio.emit("telemetry_update", telemetry_state)


# ==============================================================================
# BACKGROUND HEARTBEAT MONITOR THREAD
# ==============================================================================
def heartbeat_monitor():
    """
    Periodically checks if ESP32 telemetry packet arrival has timed out.
    If no packet received in HEARTBEAT_TIMEOUT_SEC seconds, sets ESP32 to OFFLINE.
    This guarantees NO FAKE ASSUMPTION of connection.
    """
    logger.info(f"ESP32 Heartbeat monitor started (Timeout: {HEARTBEAT_TIMEOUT_SEC}s).")
    while True:
        time.sleep(2.0)
        with state_lock:
            if telemetry_state["online"]:
                last_seen = telemetry_state["last_seen_timestamp"]
                if last_seen and (time.time() - last_seen > HEARTBEAT_TIMEOUT_SEC):
                    telemetry_state["online"] = False
                    telemetry_state["wifi_connected"] = False
                    add_alert(
                        "ESP32 OFFLINE",
                        f"Hardware heartbeat lost. No telemetry received for >{int(HEARTBEAT_TIMEOUT_SEC)} seconds.",
                        "DANGER"
                    )
                    socketio.emit("telemetry_update", telemetry_state)


# Start Heartbeat Thread as Daemon
monitor_thread = Thread(target=heartbeat_monitor, daemon=True)
monitor_thread.start()


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    logger.info(f"Starting Mining V2V Server on http://0.0.0.0:{port}")
    socketio.run(app, host="0.0.0.0", port=port, debug=False, allow_unsafe_werkzeug=True)
