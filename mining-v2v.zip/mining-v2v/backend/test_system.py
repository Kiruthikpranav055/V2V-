"""
Mining V2V System Verification & Integration Test Suite
Verifies:
1. Initial clean state (NO fake data)
2. Static file serving (HTML, CSS, JS)
3. 50 cm safety stop automation rule
4. Refusal to unlock when obstacle <= 50 cm
5. Successful unlock when obstacle is cleared
6. Movement command blocking during safety lock
"""

import sys
import os

# Add backend directory to path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from app import app, telemetry_state, SAFETY_DISTANCE_CM

def run_tests():
    print("==============================================================")
    print("MINING V2V SAFETY SYSTEM - INTEGRATION VERIFICATION")
    print("==============================================================")

    client = app.test_client()

    # Test 1: Check initial state has NO fake values
    print("\n[TEST 1] Verifying initial telemetry state (Zero fake data rule)...")
    res = client.get("/api/sensor-data")
    assert res.status_code == 200, f"Expected 200, got {res.status_code}"
    data = res.get_json()["telemetry"]
    assert data["online"] is False, "ESP32 should initially be offline"
    assert data["temperature"] is None, "Temperature should initially be None"
    assert data["humidity"] is None, "Humidity should initially be None"
    assert data["distance_cm"] is None, "Distance should initially be None"
    assert data["gps_valid"] is False, "GPS should initially have no fix"
    print("[PASS] Initial state cleanly reflects NO DATA and OFFLINE.")

    # Test 2: Check frontend static files serving
    print("\n[TEST 2] Verifying frontend static routes...")
    res_index = client.get("/")
    assert res_index.status_code == 200, f"Expected 200, got {res_index.status_code}"
    assert "MINING V2V SAFETY MONITOR" in res_index.get_data(as_text=True)

    res_css = client.get("/style.css")
    assert res_css.status_code == 200
    assert "--color-danger" in res_css.get_data(as_text=True)

    res_js = client.get("/script.js")
    assert res_js.status_code == 200
    assert "SAFETY_DISTANCE_THRESHOLD_CM" in res_js.get_data(as_text=True)
    print("[PASS] Frontend index.html, style.css, and script.js served successfully.")

    # Test 3: Send normal sensor data (> 50 cm)
    print("\n[TEST 3] Ingesting normal sensor packet (Distance: 120 cm > 50 cm threshold)...")
    packet_normal = {
        "temperature": 27.5,
        "humidity": 55.0,
        "rain": False,
        "distance_cm": 120.0,
        "tilt_pitch": 2.0,
        "tilt_roll": 1.0,
        "vibration_level": 0.2,
        "stability": "STABLE",
        "motor": "RUNNING",
        "motor_locked": False,
        "buzzer": False,
        "latitude": 23.50,
        "longitude": 85.30,
        "gps_valid": True,
        "gps_satellites": 8,
        "lora_connected": True,
        "safety_state": "NORMAL"
    }
    res_post1 = client.post("/api/sensor-data", json=packet_normal)
    assert res_post1.status_code == 200
    assert telemetry_state["online"] is True
    assert telemetry_state["distance_cm"] == 120.0
    assert telemetry_state["safety_state"] == "NORMAL"
    assert telemetry_state["motor_locked"] is False
    print("[PASS] Normal packet processed. Vehicle state is NORMAL.")

    # Test 4: OBSTACLE TRIGGER <= 50 cm (AUTOMATIC SAFETY STOP)
    print("\n[TEST 4] Triggering obstacle at 42.5 cm (<= 50 cm hard barrier)...")
    packet_hazard = {
        "temperature": 27.5,
        "humidity": 55.0,
        "rain": False,
        "distance_cm": 42.5,
        "tilt_pitch": 2.0,
        "tilt_roll": 1.0,
        "vibration_level": 0.2,
        "stability": "STABLE",
        "motor": "STOPPED",
        "motor_locked": True,
        "buzzer": True,
        "latitude": 23.50,
        "longitude": 85.30,
        "gps_valid": True,
        "gps_satellites": 8,
        "lora_connected": True,
        "safety_state": "AUTO_STOP"
    }
    res_post2 = client.post("/api/sensor-data", json=packet_hazard)
    assert res_post2.status_code == 200
    assert telemetry_state["distance_cm"] == 42.5
    assert telemetry_state["safety_state"] == "AUTO_STOP"
    assert telemetry_state["motor_locked"] is True
    assert telemetry_state["motor"] == "LOCKED"
    assert telemetry_state["buzzer"] is True
    print("[PASS] AUTO STOP TRIGGERED: Motor LOCKED, Buzzer ON, State: AUTO_STOP.")

    # Test 5: Try manual directional commands while locked (FORWARD, BACKWARD, LEFT, RIGHT)
    print("\n[TEST 5] Attempting directional movements while motor is locked (Must be BLOCKED)...")
    for cmd in ["FORWARD", "BACKWARD", "LEFT", "RIGHT"]:
        res_move = client.post("/api/motor/control", json={"command": cmd})
        assert res_move.status_code == 403, f"Expected 403 Forbidden for {cmd}, got {res_move.status_code}"
    print("[PASS] All directional movements (FORWARD, BACKWARD, LEFT, RIGHT) BLOCKED by safety lock (403 Forbidden).")

    # Test 6: Attempt Reset while obstacle is still <= 50 cm (Must be REJECTED)
    print("\n[TEST 6] Attempting reset while obstacle is STILL <= 50 cm...")
    res_reset_fail = client.post("/api/safety/reset")
    assert res_reset_fail.status_code == 400, f"Expected 400 Bad Request, got {res_reset_fail.status_code}"
    assert telemetry_state["motor_locked"] is True, "Motor must stay locked"
    print("[PASS] Safety reset correctly REJECTED (400 Bad Request): Obstacle still present.")

    # Test 7: Obstacle clears (150 cm), but vehicle MUST REMAIN LOCKED until intentional reset
    print("\n[TEST 7] Obstacle moves away to 150 cm (Vehicle MUST stay locked until reset)...")
    packet_cleared = {
        "temperature": 27.5,
        "humidity": 55.0,
        "rain": False,
        "distance_cm": 150.0,
        "tilt_pitch": 2.0,
        "tilt_roll": 1.0,
        "vibration_level": 0.2,
        "stability": "STABLE",
        "motor": "STOPPED",
        "motor_locked": True,  # Hardware maintains lock
        "buzzer": True,
        "latitude": 23.50,
        "longitude": 85.30,
        "gps_valid": True,
        "gps_satellites": 8,
        "lora_connected": True,
        "safety_state": "MOTOR_LOCKED"
    }
    client.post("/api/sensor-data", json=packet_cleared)
    assert telemetry_state["motor_locked"] is True, "Vehicle must remain locked!"
    print("[PASS] Vehicle correctly remained MOTOR_LOCKED even after obstacle moved away.")

    # Test 8: Authorized Operator Reset with obstacle clear (Must SUCCEED)
    print("\n[TEST 8] Executing authorized operator reset with path clear...")
    res_reset_ok = client.post("/api/safety/reset")
    assert res_reset_ok.status_code == 200, f"Expected 200 OK, got {res_reset_ok.status_code}"
    assert telemetry_state["motor_locked"] is False
    assert telemetry_state["safety_state"] == "NORMAL"
    assert telemetry_state["buzzer"] is False
    assert telemetry_state["pending_unlock_request"] is True
    print("[PASS] Safety lock released successfully! State restored to NORMAL.")

    # Test 9: Verify downlink on next ESP32 POST carries unlock_command
    print("\n[TEST 9] Verifying downlink sync response to ESP32 carries unlock_command...")
    res_downlink = client.post("/api/sensor-data", json={
        "distance_cm": 150.0,
        "motor_locked": False,
        "safety_state": "NORMAL"
    })
    assert res_downlink.status_code == 200
    downlink_data = res_downlink.get_json()
    assert downlink_data["unlock_command"] is True, "Downlink must notify ESP32 to unlock hardware"
    print("[PASS] Downlink unlock_command successfully transmitted to ESP32.")

    print("\n==============================================================")
    print("ALL 9 INTEGRATION & SAFETY TESTS PASSED WITH 100% SUCCESS!")
    print("==============================================================")
    os._exit(0)

if __name__ == "__main__":
    run_tests()
