/**
 * MINING VEHICLE-TO-VEHICLE (V2V) SAFETY MONITORING SYSTEM
 * Production Embedded Firmware for ESP32
 * 
 * Hardware Modules:
 *  1. ESP32 DevKit V1 (Main Controller)
 *  2. Dual DC Motor Driver (L298N / TB6612: Forward / Backward / Left / Right)
 *  3. MPU6050 6-DoF IMU (Vehicle Tilt, Vibration, Roll/Pitch Stability)
 *  4. Rain Sensor Module (Mining Haul Road Wet Condition Detection)
 *  5. DHT11 / DHT22 (Ambient Underground/Open-Pit Temp & Humidity)
 *  6. NEO-6M GPS Module (Real-Time Mining Fleet Geolocation)
 *  7. HC-SR04 Ultrasonic Sensor (Obstacle Detection & Safety Stop)
 *  8. Active Buzzer (Audible In-Cab Danger Warning)
 *  9. SSD1306 0.96" OLED (Local Vehicle In-Cab Diagnostics)
 * 10. Hardware Reset Button (Manual Safety Interlock Release)
 * 
 * HARD SAFETY RULE:
 *  When distance <= 50 cm:
 *   - Motors stop immediately in ALL directions
 *   - Motor driver locked
 *   - Manual movement commands (FWD/BACK/LEFT/RIGHT) blocked
 *   - Buzzer turned ON
 *   - Safety state becomes AUTO_STOP / HIGH_RISK
 *   - Stays LOCKED until physical/authorized UNLOCK action performed!
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <DHT.h>
#include <TinyGPS++.h>

#include "config.h"

// ==============================================================================
// GLOBAL OBJECTS & DRIVERS
// ==============================================================================
Adafruit_SSD1306 oled(OLED_SCREEN_WIDTH, OLED_SCREEN_HEIGHT, &Wire, OLED_RESET_PIN);
Adafruit_MPU6050 mpu;
DHT dht(PIN_DHT, DHTTYPE);
TinyGPSPlus gps;
HardwareSerial gpsSerial(2); // ESP32 Serial2 (GPIO 16 RX, GPIO 17 TX)

// ==============================================================================
// VEHICLE STATE MACHINE & SAFETY FLAGS
// ==============================================================================
bool motorLocked           = false; // Hardware safety interlock
bool manualControlLocked   = false;
bool buzzerActive          = false;
String safetyState         = "NORMAL";  // NORMAL | WARNING | HIGH_RISK | AUTO_STOP | MOTOR_LOCKED
String motorState          = "STOPPED"; // STOPPED | FORWARD | BACKWARD | LEFT | RIGHT | LOCKED

// Sensor Availability & Health Flags
bool dhtConnected          = false;
bool mpuConnected          = false;
bool oledConnected         = false;
bool gpsValid              = false;

// Last Telemetry Timing
unsigned long lastTelemetryTime = 0;

// ==============================================================================
// 4-DIRECTIONAL DUAL DC MOTOR CONTROL (HARDWARE SAFETY PRIORITY)
// ==============================================================================
void initDualMotorHardware() {
  pinMode(PIN_MOTOR_LEFT_IN1, OUTPUT);
  pinMode(PIN_MOTOR_LEFT_IN2, OUTPUT);
  pinMode(PIN_MOTOR_RIGHT_IN3, OUTPUT);
  pinMode(PIN_MOTOR_RIGHT_IN4, OUTPUT);

  // ESP32 LEDC PWM Speed Control Channels
  #if ESP_ARDUINO_VERSION_MAJOR >= 3
    ledcAttach(PIN_MOTOR_LEFT_PWM, MOTOR_PWM_FREQ, MOTOR_PWM_RES);
    ledcAttach(PIN_MOTOR_RIGHT_PWM, MOTOR_PWM_FREQ, MOTOR_PWM_RES);
  #else
    ledcSetup(0, MOTOR_PWM_FREQ, MOTOR_PWM_RES);
    ledcAttachPin(PIN_MOTOR_LEFT_PWM, 0);
    ledcSetup(1, MOTOR_PWM_FREQ, MOTOR_PWM_RES);
    ledcAttachPin(PIN_MOTOR_RIGHT_PWM, 1);
  #endif

  stopAllMotors();
}

void stopAllMotors() {
  digitalWrite(PIN_MOTOR_LEFT_IN1, LOW);
  digitalWrite(PIN_MOTOR_LEFT_IN2, LOW);
  digitalWrite(PIN_MOTOR_RIGHT_IN3, LOW);
  digitalWrite(PIN_MOTOR_RIGHT_IN4, LOW);

  #if ESP_ARDUINO_VERSION_MAJOR >= 3
    ledcWrite(PIN_MOTOR_LEFT_PWM, 0);
    ledcWrite(PIN_MOTOR_RIGHT_PWM, 0);
  #else
    ledcWrite(0, 0);
    ledcWrite(1, 0);
  #endif

  if (!motorLocked) {
    motorState = "STOPPED";
  }
}

void moveForwardHardware() {
  if (motorLocked || manualControlLocked) { stopAllMotors(); return; }
  digitalWrite(PIN_MOTOR_LEFT_IN1, HIGH);
  digitalWrite(PIN_MOTOR_LEFT_IN2, LOW);
  digitalWrite(PIN_MOTOR_RIGHT_IN3, HIGH);
  digitalWrite(PIN_MOTOR_RIGHT_IN4, LOW);

  #if ESP_ARDUINO_VERSION_MAJOR >= 3
    ledcWrite(PIN_MOTOR_LEFT_PWM, MOTOR_DRIVE_SPEED);
    ledcWrite(PIN_MOTOR_RIGHT_PWM, MOTOR_DRIVE_SPEED);
  #else
    ledcWrite(0, MOTOR_DRIVE_SPEED);
    ledcWrite(1, MOTOR_DRIVE_SPEED);
  #endif
  motorState = "FORWARD";
}

void moveBackwardHardware() {
  if (motorLocked || manualControlLocked) { stopAllMotors(); return; }
  digitalWrite(PIN_MOTOR_LEFT_IN1, LOW);
  digitalWrite(PIN_MOTOR_LEFT_IN2, HIGH);
  digitalWrite(PIN_MOTOR_RIGHT_IN3, LOW);
  digitalWrite(PIN_MOTOR_RIGHT_IN4, HIGH);

  #if ESP_ARDUINO_VERSION_MAJOR >= 3
    ledcWrite(PIN_MOTOR_LEFT_PWM, MOTOR_DRIVE_SPEED);
    ledcWrite(PIN_MOTOR_RIGHT_PWM, MOTOR_DRIVE_SPEED);
  #else
    ledcWrite(0, MOTOR_DRIVE_SPEED);
    ledcWrite(1, MOTOR_DRIVE_SPEED);
  #endif
  motorState = "BACKWARD";
}

void turnLeftHardware() {
  if (motorLocked || manualControlLocked) { stopAllMotors(); return; }
  // Differential turn: Left motor backward, Right motor forward
  digitalWrite(PIN_MOTOR_LEFT_IN1, LOW);
  digitalWrite(PIN_MOTOR_LEFT_IN2, HIGH);
  digitalWrite(PIN_MOTOR_RIGHT_IN3, HIGH);
  digitalWrite(PIN_MOTOR_RIGHT_IN4, LOW);

  #if ESP_ARDUINO_VERSION_MAJOR >= 3
    ledcWrite(PIN_MOTOR_LEFT_PWM, MOTOR_TURN_SPEED);
    ledcWrite(PIN_MOTOR_RIGHT_PWM, MOTOR_TURN_SPEED);
  #else
    ledcWrite(0, MOTOR_TURN_SPEED);
    ledcWrite(1, MOTOR_TURN_SPEED);
  #endif
  motorState = "LEFT";
}

void turnRightHardware() {
  if (motorLocked || manualControlLocked) { stopAllMotors(); return; }
  // Differential turn: Left motor forward, Right motor backward
  digitalWrite(PIN_MOTOR_LEFT_IN1, HIGH);
  digitalWrite(PIN_MOTOR_LEFT_IN2, LOW);
  digitalWrite(PIN_MOTOR_RIGHT_IN3, LOW);
  digitalWrite(PIN_MOTOR_RIGHT_IN4, HIGH);

  #if ESP_ARDUINO_VERSION_MAJOR >= 3
    ledcWrite(PIN_MOTOR_LEFT_PWM, MOTOR_TURN_SPEED);
    ledcWrite(PIN_MOTOR_RIGHT_PWM, MOTOR_TURN_SPEED);
  #else
    ledcWrite(0, MOTOR_TURN_SPEED);
    ledcWrite(1, MOTOR_TURN_SPEED);
  #endif
  motorState = "RIGHT";
}

void executeMotorDirection(String cmd) {
  // STRICT SAFETY BARRIER: If locked, force stop immediately
  if (motorLocked || manualControlLocked) {
    stopAllMotors();
    return;
  }

  if (cmd == "FORWARD") {
    moveForwardHardware();
  } else if (cmd == "BACKWARD" || cmd == "REVERSE") {
    moveBackwardHardware();
  } else if (cmd == "LEFT") {
    turnLeftHardware();
  } else if (cmd == "RIGHT") {
    turnRightHardware();
  } else {
    stopAllMotors();
  }
}

// ==============================================================================
// ULTRASONIC SENSOR MEASUREMENT
// ==============================================================================
bool readUltrasonicDistance(float &distanceOut) {
  digitalWrite(PIN_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(PIN_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);

  // 35,000 microseconds timeout gives approx 600 cm max pulse window
  long duration = pulseIn(PIN_ECHO, HIGH, 35000);

  if (duration == 0) {
    // No echo received (obstacle out of range or sensor disconnected)
    return false;
  }

  // Speed of sound = 343 m/s = 0.0343 cm/microsecond
  float dist = (duration * 0.0343) / 2.0;

  if (dist < MIN_SENSOR_RANGE_CM || dist > MAX_SENSOR_RANGE_CM) {
    return false;
  }

  distanceOut = dist;
  return true;
}

// ==============================================================================
// MPU6050 DYNAMICS & INERTIAL ANALYSIS
// ==============================================================================
void readMPU6050Dynamics(float &pitch, float &roll, float &vibG, String &stability) {
  if (!mpuConnected) {
    stability = "UNKNOWN";
    return;
  }

  sensors_event_t a, g, temp;
  if (!mpu.getEvent(&a, &g, &temp)) {
    stability = "ERROR";
    return;
  }

  // Calculate Roll and Pitch angles from Accelerometer (in degrees)
  pitch = atan2(-a.acceleration.x, sqrt(a.acceleration.y * a.acceleration.y + a.acceleration.z * a.acceleration.z)) * 180.0 / PI;
  roll  = atan2(a.acceleration.y, a.acceleration.z) * 180.0 / PI;

  // Dynamic vibration jerk
  float totalAccel = sqrt(a.acceleration.x * a.acceleration.x + 
                          a.acceleration.y * a.acceleration.y + 
                          a.acceleration.z * a.acceleration.z);
  vibG = abs(totalAccel - 9.806) / 9.806;

  // Classify Mining Vehicle Stability
  if (abs(roll) > ROLL_TILT_LIMIT_DEG || abs(pitch) > PITCH_TILT_LIMIT_DEG) {
    stability = "TILT_DETECTED";
  } else if (vibG > VIBRATION_LIMIT_G) {
    stability = "HIGH_VIBRATION";
  } else {
    stability = "STABLE";
  }
}

// ==============================================================================
// OLED DISPLAY UPDATE (LOCAL IN-CAB TELEMETRY)
// ==============================================================================
void updateOLED(float distance, bool validDist, bool rain, float temp, bool validTemp) {
  if (!oledConnected) return;

  oled.clearDisplay();
  oled.setTextSize(1);
  oled.setTextColor(SSD1306_WHITE);

  // Line 0: Title Banner
  oled.setCursor(0, 0);
  oled.print(F("MINING V2V: "));
  oled.print(safetyState);

  // Line 1: Obstacle Distance & Safety Limit
  oled.setCursor(0, 14);
  oled.print(F("DIST: "));
  if (validDist) {
    oled.print(distance, 1);
    oled.print(F("cm "));
    if (distance <= SAFETY_DISTANCE_CM) {
      oled.print(F("[ALERT!]"));
    } else {
      oled.print(F("[OK]"));
    }
  } else {
    oled.print(F("NO DATA"));
  }

  // Line 2: Motor Direction & Buzzer
  oled.setCursor(0, 26);
  oled.print(F("MTR: "));
  oled.print(motorState);
  oled.print(F(" BUZ:"));
  oled.print(buzzerActive ? F("ON") : F("OFF"));

  // Line 3: Environmental (Rain & Temp)
  oled.setCursor(0, 38);
  oled.print(F("RAIN: "));
  oled.print(rain ? F("YES") : F("NO"));
  oled.print(F(" T:"));
  if (validTemp) {
    oled.print(temp, 1);
    oled.print(F("C"));
  } else {
    oled.print(F("--"));
  }

  // Line 4: IP Address
  oled.setCursor(0, 50);
  if (WiFi.status() == WL_CONNECTED) {
    oled.print(F("IP: "));
    oled.print(WiFi.localIP().toString());
  } else {
    oled.print(F("WIFI: RECONNECTING"));
  }

  oled.display();
}

// ==============================================================================
// SETUP INITIALIZATION
// ==============================================================================
void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println(F("\n=============================================="));
  Serial.println(F("MINING V2V SAFETY SYSTEM - FIRMWARE BOOTING"));
  Serial.println(F("=============================================="));

  // Initialize GPIOs
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  pinMode(PIN_BUZZER, OUTPUT);
  pinMode(PIN_RAIN_DO, INPUT);
  pinMode(PIN_SAFETY_RESET, INPUT_PULLUP);

  digitalWrite(PIN_BUZZER, LOW);

  // Initialize Dual DC Motors (Forward/Back/Left/Right)
  initDualMotorHardware();

  // Initialize I2C Bus
  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL);

  // Initialize OLED Display (0x3C)
  if (oled.begin(SSD1306_SWITCHCAPVCC, OLED_I2C_ADDRESS)) {
    oledConnected = true;
    oled.clearDisplay();
    oled.setTextSize(1);
    oled.setTextColor(SSD1306_WHITE);
    oled.setCursor(0, 10);
    oled.println(F("Mining V2V System"));
    oled.println(F("Dual Motors Ready..."));
    oled.display();
    Serial.println(F("[OK] SSD1306 OLED Display Detected."));
  } else {
    Serial.println(F("[WARN] SSD1306 OLED Display not found on 0x3C."));
  }

  // Initialize MPU6050
  if (mpu.begin()) {
    mpuConnected = true;
    mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
    mpu.setGyroRange(MPU6050_RANGE_500_DEG);
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
    Serial.println(F("[OK] MPU6050 6-DoF IMU Detected."));
  } else {
    Serial.println(F("[WARN] MPU6050 IMU not detected. Stability will report UNKNOWN."));
  }

  // Initialize DHT Sensor
  dht.begin();
  Serial.println(F("[OK] DHT Sensor Initialized."));

  // Initialize GPS Serial2
  gpsSerial.begin(GPS_BAUD_RATE, SERIAL_8N1, PIN_GPS_RX, PIN_GPS_TX);
  Serial.println(F("[OK] GPS Serial2 Initialized."));

  // Connect to Wi-Fi
  Serial.print(F("Connecting to Wi-Fi SSID: "));
  Serial.println(WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  int wifiAttempts = 0;
  while (WiFi.status() != WL_CONNECTED && wifiAttempts < 20) {
    delay(500);
    Serial.print(F("."));
    wifiAttempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println(F("\n[OK] Wi-Fi Connected."));
    Serial.print(F("ESP32 IP Address: "));
    Serial.println(WiFi.localIP());
  } else {
    Serial.println(F("\n[WARN] Wi-Fi Connection Pending/Failed. Continuing offline safety monitoring."));
  }
}

// ==============================================================================
// MAIN SUPERVISORY LOOP
// ==============================================================================
void loop() {
  // Feed GPS Serial incoming bytes
  while (gpsSerial.available() > 0) {
    gps.encode(gpsSerial.read());
  }

  // Read Ultrasonic Obstacle Distance
  float distance_cm = 0.0;
  bool validDistance = readUltrasonicDistance(distance_cm);

  // Read Rain Sensor (LM393 DO is active LOW when droplets hit board)
  int rainRaw = digitalRead(PIN_RAIN_DO);
  bool rainDetected = (rainRaw == LOW);

  // Read DHT Sensor
  float temperature = dht.readTemperature();
  float humidity    = dht.readHumidity();
  bool validDHT     = (!isnan(temperature) && !isnan(humidity));

  // Read MPU6050 Dynamics
  float pitch = 0.0, roll = 0.0, vibG = 0.0;
  String stability = "UNKNOWN";
  readMPU6050Dynamics(pitch, roll, vibG, stability);

  // Read GPS Status
  bool validGPS = (gps.location.isValid() && gps.location.age() < 5000);

  // ============================================================================
  // AUTOMATIC HARDWARE SAFETY STOP LOGIC (SAFETY_DISTANCE_CM = 50 cm)
  // ============================================================================
  if (validDistance && (distance_cm <= SAFETY_DISTANCE_CM)) {
    // 1. ESP32 must immediately stop ALL DC motors
    stopAllMotors();

    // 2. Motor driver must enter MOTOR LOCKED state
    motorLocked = true;
    manualControlLocked = true;
    motorState = "LOCKED";

    // 3. Buzzer must turn ON
    buzzerActive = true;
    digitalWrite(PIN_BUZZER, HIGH);

    // 4. Vehicle status must become AUTO_STOP / HIGH_RISK
    safetyState = "AUTO_STOP";

    Serial.print(F("[CRITICAL SAFETY STOP] Obstacle detected at "));
    Serial.print(distance_cm, 1);
    Serial.println(F(" cm (<= 50 cm). MOTOR LOCKED! BUZZER ON!"));
  }

  // ============================================================================
  // SAFETY UNLOCK LOGIC
  // When obstacle is removed, motor MUST REMAIN LOCKED until intentional RESET!
  // ============================================================================
  bool physicalResetPressed = (digitalRead(PIN_SAFETY_RESET) == LOW);
  
  if (motorLocked && physicalResetPressed) {
    // Verify that obstacle is clear (> 50 cm or clear) before unlocking
    if (!validDistance || (distance_cm > SAFETY_DISTANCE_CM)) {
      motorLocked = false;
      manualControlLocked = false;
      buzzerActive = false;
      digitalWrite(PIN_BUZZER, LOW);
      motorState = "STOPPED";
      safetyState = "NORMAL";
      Serial.println(F("[SAFETY UNLOCK] Physical Reset Button pressed. Obstacle cleared. System restored to NORMAL."));
    } else {
      Serial.println(F("[SAFETY INTERLOCK] Unlock rejected! Obstacle is still detected <= 50 cm."));
    }
  }

  // Evaluate secondary states if not in emergency AUTO_STOP lock
  if (!motorLocked) {
    if (rainDetected && (stability != "STABLE")) {
      safetyState = "HIGH_RISK";
    } else if (rainDetected || (stability == "TILT_DETECTED") || (stability == "HIGH_VIBRATION")) {
      safetyState = "WARNING";
    } else {
      safetyState = "NORMAL";
    }
  }

  // Local OLED Screen Refresh
  updateOLED(distance_cm, validDistance, rainDetected, temperature, validDHT);

  // ============================================================================
  // HTTP POST TELEMETRY TO FLASK BACKEND & RECEIVE DIRECTION COMMANDS
  // ============================================================================
  if (millis() - lastTelemetryTime >= TELEMETRY_INTERVAL_MS) {
    lastTelemetryTime = millis();

    if (WiFi.status() == WL_CONNECTED) {
      HTTPClient http;
      http.begin(BACKEND_SERVER_URL);
      http.addHeader("Content-Type", "application/json");

      // Construct JSON payload using ArduinoJson (NO FAKE SENSOR DATA)
      StaticJsonDocument<512> doc;

      // Environmental Sensors
      if (validDHT) {
        doc["temperature"] = temperature;
        doc["humidity"]    = humidity;
      } else {
        doc["temperature"] = nullptr;
        doc["humidity"]    = nullptr;
      }

      // Rain Sensor
      doc["rain"] = rainDetected;

      // Ultrasonic Sensor
      if (validDistance) {
        doc["distance_cm"] = distance_cm;
      } else {
        doc["distance_cm"] = nullptr;
      }

      // MPU6050
      if (mpuConnected) {
        doc["tilt_pitch"]      = pitch;
        doc["tilt_roll"]       = roll;
        doc["vibration_level"] = vibG;
        doc["stability"]       = stability;
        doc["mpu_connected"]   = true;
      } else {
        doc["tilt_pitch"]      = nullptr;
        doc["tilt_roll"]       = nullptr;
        doc["vibration_level"] = nullptr;
        doc["stability"]       = "UNKNOWN";
        doc["mpu_connected"]   = false;
      }

      // Actuators & Safety States
      doc["motor"]         = motorState;
      doc["motor_locked"]  = motorLocked;
      doc["buzzer"]        = buzzerActive;
      doc["safety_state"]  = safetyState;

      // GPS Geolocation
      if (validGPS) {
        doc["gps_valid"]      = true;
        doc["latitude"]       = gps.location.lat();
        doc["longitude"]      = gps.location.lng();
        doc["altitude_m"]     = gps.altitude.meters();
        doc["speed_kmh"]      = gps.speed.kmph();
        doc["gps_satellites"] = gps.satellites.value();
      } else {
        doc["gps_valid"]      = false;
        doc["latitude"]       = nullptr;
        doc["longitude"]      = nullptr;
      }

      String jsonPayload;
      serializeJson(doc, jsonPayload);

      int httpResponseCode = http.POST(jsonPayload);
      if (httpResponseCode > 0) {
        String response = http.getString();
        
        // Parse Downlink Response for Directional Movement & Unlock Command
        StaticJsonDocument<256> respDoc;
        DeserializationError err = deserializeJson(respDoc, response);
        if (!err) {
          // 1. Authorized Remote Unlock Command
          bool serverUnlock = respDoc["unlock_command"] | false;
          if (serverUnlock && motorLocked) {
            // Verify obstacle is clear before executing remote unlock
            if (!validDistance || (distance_cm > SAFETY_DISTANCE_CM)) {
              motorLocked = false;
              manualControlLocked = false;
              buzzerActive = false;
              digitalWrite(PIN_BUZZER, LOW);
              motorState = "STOPPED";
              safetyState = "NORMAL";
              Serial.println(F("[SAFETY UNLOCK] Server authorized unlock command executed. System restored to NORMAL."));
            }
          }

          // 2. Directional Movement Command (FORWARD, BACKWARD, LEFT, RIGHT, STOP)
          if (!motorLocked && !manualControlLocked) {
            String dirCmd = respDoc["motor_command"] | "STOP";
            executeMotorDirection(dirCmd);
          } else {
            stopAllMotors();
          }
        }
      } else {
        Serial.print(F("[WARN] HTTP POST failed, error: "));
        Serial.println(http.errorToString(httpResponseCode).c_str());
      }
      http.end();
    } else {
      // Wi-Fi Disconnected - Attempt auto-reconnect in background
      Serial.println(F("[WARN] Wi-Fi disconnected. Reconnecting..."));
      WiFi.reconnect();
    }
  }

  delay(20); // Cooperative multitasking delay
}
