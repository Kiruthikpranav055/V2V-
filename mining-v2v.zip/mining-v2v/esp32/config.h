/**
 * Mining Vehicle-to-Vehicle (V2V) Safety Monitoring System
 * Hardware Configuration & Pinout Header
 * Target MCU: ESP32 DevKit V1 (30/38 Pin)
 */

#ifndef CONFIG_H
#define CONFIG_H

// ==============================================================================
// 1. WI-FI & BACKEND SERVER CONFIGURATION
// ==============================================================================
// Replace with your real Wi-Fi network SSID and Password
#define WIFI_SSID         "YOUR_WIFI_SSID"
#define WIFI_PASSWORD     "YOUR_WIFI_PASSWORD"

// Backend API URL: Replace with your Flask Server's IP address on the local network
// e.g. "http://192.168.1.100:5000/api/sensor-data"
#define BACKEND_SERVER_URL "http://192.168.1.100:5000/api/sensor-data"

// Telemetry Transmission Interval (milliseconds)
#define TELEMETRY_INTERVAL_MS 1000

// ==============================================================================
// 2. SAFETY AUTOMATION THRESHOLDS
// ==============================================================================
// Hard requirement: Obstacle safety barrier = 50 cm (0.5 meter, NOT 50 meters)
const float SAFETY_DISTANCE_CM     = 50.0; 
const float MAX_SENSOR_RANGE_CM    = 999.0;
const float MIN_SENSOR_RANGE_CM    = 2.0;

// MPU6050 Dynamics Safety Thresholds
const float ROLL_TILT_LIMIT_DEG    = 25.0; // Roll angle warning (rollover risk)
const float PITCH_TILT_LIMIT_DEG   = 25.0; // Pitch angle warning (steep mining slope)
const float VIBRATION_LIMIT_G      = 2.8;  // High vibration threshold (mining terrain jerk)

// ==============================================================================
// 3. HARDWARE PIN DEFINITIONS (ESP32 DevKit V1)
// ==============================================================================

// --- Ultrasonic Sensor (HC-SR04) ---
#define PIN_TRIG          12   // Ultrasonic Trigger (Output)
#define PIN_ECHO          13   // Ultrasonic Echo (Input - 3.3V safe or via 1k/2k divider)

// --- Dual DC Motor Driver (L298N / TB6612 Dual H-Bridge: Forward/Back/Left/Right) ---
// Left Motor Channel
#define PIN_MOTOR_LEFT_IN1    26   // Left Motor Direction 1
#define PIN_MOTOR_LEFT_IN2    33   // Left Motor Direction 2
#define PIN_MOTOR_LEFT_PWM    32   // Left Motor Speed PWM (LEDC Channel 0)

// Right Motor Channel (Differential Steering)
#define PIN_MOTOR_RIGHT_IN3   18   // Right Motor Direction 1
#define PIN_MOTOR_RIGHT_IN4   19   // Right Motor Direction 2
#define PIN_MOTOR_RIGHT_PWM   23   // Right Motor Speed PWM (LEDC Channel 1)

#define MOTOR_PWM_FREQ        5000 // 5 kHz PWM frequency
#define MOTOR_PWM_RES         8    // 8-bit resolution (0 - 255)
#define MOTOR_DRIVE_SPEED     210  // Driving speed
#define MOTOR_TURN_SPEED      180  // Differential turning speed

// --- Buzzer (Physical Safety Warning) ---
#define PIN_BUZZER            25   // Active Buzzer (Active HIGH)

// --- Rain Sensor (LM393 Module) ---
#define PIN_RAIN_DO           27   // Rain Digital Output (Active LOW when wet)

// --- DHT Sensor (DHT11 or DHT22) ---
#define PIN_DHT               4    // DHT Data Pin
#define DHTTYPE               DHT11 // Set to DHT11 or DHT22

// --- GPS Module (NEO-6M on Hardware Serial 2) ---
#define PIN_GPS_RX            16   // ESP32 RX2 connects to GPS Module TX
#define PIN_GPS_TX            17   // ESP32 TX2 connects to GPS Module RX
#define GPS_BAUD_RATE         9600

// --- I2C Bus: MPU6050 (0x68) & OLED Display (0x3C) ---
#define PIN_I2C_SDA       21   // ESP32 Default SDA
#define PIN_I2C_SCL       22   // ESP32 Default SCL
#define OLED_SCREEN_WIDTH 128
#define OLED_SCREEN_HEIGHT 64
#define OLED_I2C_ADDRESS  0x3C
#define OLED_RESET_PIN    -1   // Share ESP32 reset

// --- Physical Safety Reset / Unlock Push Button ---
#define PIN_SAFETY_RESET  15   // INPUT_PULLUP: Press to unlock when safe

#endif // CONFIG_H
