/**
 * MINING V2V SAFETY MONITORING SYSTEM
 * Real-Time Industrial Web Dashboard Controller
 * 
 * Strict Constraint: NO FAKE / RANDOM SENSOR DATA GENERATOR.
 * Telemetry is ingested solely from real ESP32 hardware via WebSocket & REST API.
 */

// ==============================================================================
// CONFIGURATION & GLOBAL STATE
// ==============================================================================
const SAFETY_DISTANCE_THRESHOLD_CM = 50.0; // 50 cm = 0.5 meter (Hard Safety Barrier)

let socket = null;
let leafletMap = null;
let vehicleMarker = null;
let hasInitialMapPan = false;
let pollingInterval = null;

// Telemetry State Cache (Clean default - No fake values)
let currentTelemetry = {
  online: false,
  last_seen_readable: "NEVER",
  ip_address: null,
  packet_count: 0,
  wifi_connected: false,

  safety_state: "NORMAL",
  safety_distance_cm: SAFETY_DISTANCE_THRESHOLD_CM,

  temperature: null,
  humidity: null,
  dht_connected: false,
  rain: false,
  rain_status: "NO DATA",

  distance_cm: null,
  distance_status: "NO DATA",
  obstacle_detected: false,

  tilt_pitch: null,
  tilt_roll: null,
  vibration_level: null,
  stability: "UNKNOWN",
  mpu_connected: false,

  motor: "STOPPED",
  motor_command: "STOP",
  motor_locked: false,
  manual_control_locked: false,
  buzzer: false,

  latitude: null,
  longitude: null,
  altitude_m: null,
  speed_kmh: null,
  gps_valid: false,
  gps_satellites: 0,
  gps_status: "NO FIX"
};

// ==============================================================================
// DOM ELEMENT CACHE
// ==============================================================================
const dom = {
  // Header Connection Badges
  dotEsp32: document.getElementById("dot-esp32"),
  valEsp32: document.getElementById("val-esp32"),
  dotWifi: document.getElementById("dot-wifi"),
  valWifi: document.getElementById("val-wifi"),
  valLastSeen: document.getElementById("val-last-seen"),

  // Primary Safety Banner
  safetyBanner: document.getElementById("safety-banner"),
  safetyBadge: document.getElementById("safety-badge"),
  safetyTitle: document.getElementById("safety-title"),
  safetyDescription: document.getElementById("safety-description"),
  valObstacleFlag: document.getElementById("val-obstacle-flag"),
  valMotorLockFlag: document.getElementById("val-motor-lock-flag"),
  btnResetSafety: document.getElementById("btn-reset-safety"),
  resetHelp: document.getElementById("reset-help"),

  // Sensor Cards
  valDistance: document.getElementById("val-distance"),
  valDistanceMeters: document.getElementById("val-distance-meters"),
  barDistance: document.getElementById("bar-distance"),
  statusDistanceMsg: document.getElementById("status-distance-msg"),
  cardUltrasonic: document.getElementById("card-ultrasonic"),

  badgeDht: document.getElementById("badge-dht"),
  valTemperature: document.getElementById("val-temperature"),
  valHumidity: document.getElementById("val-humidity"),
  statusDhtMsg: document.getElementById("status-dht-msg"),

  badgeRain: document.getElementById("badge-rain"),
  valRain: document.getElementById("val-rain"),
  statusRainMsg: document.getElementById("status-rain-msg"),

  badgeMpu: document.getElementById("badge-mpu"),
  valPitch: document.getElementById("val-pitch"),
  valRoll: document.getElementById("val-roll"),
  valVibration: document.getElementById("val-vibration"),
  statusMpuMsg: document.getElementById("status-mpu-msg"),

  // DC Motor 4-Directional D-Pad Controls
  badgeMotor: document.getElementById("badge-motor"),
  valMotor: document.getElementById("val-motor"),
  btnMotorFwd: document.getElementById("btn-motor-fwd"),
  btnMotorBwd: document.getElementById("btn-motor-bwd"),
  btnMotorLeft: document.getElementById("btn-motor-left"),
  btnMotorRight: document.getElementById("btn-motor-right"),
  btnMotorStop: document.getElementById("btn-motor-stop"),
  statusMotorMsg: document.getElementById("status-motor-msg"),

  badgeBuzzer: document.getElementById("badge-buzzer"),
  valBuzzer: document.getElementById("val-buzzer"),
  statusBuzzerMsg: document.getElementById("status-buzzer-msg"),

  badgeGpsFix: document.getElementById("badge-gps-fix"),
  valLat: document.getElementById("val-lat"),
  valLng: document.getElementById("val-lng"),
  valSatellites: document.getElementById("val-satellites"),
  statusGpsMsg: document.getElementById("status-gps-msg"),

  // Map elements
  mapOverlay: document.getElementById("map-nofix-overlay"),
  chipCoordinates: document.getElementById("chip-coordinates"),
  chipSatellites: document.getElementById("chip-satellites"),

  // Alerts
  alertsContainer: document.getElementById("alerts-container"),
  alertEmptyState: document.getElementById("alert-empty-state"),

  // Diagnostics
  diagIp: document.getElementById("diag-ip"),
  diagPackets: document.getElementById("diag-packets"),
  diagTransport: document.getElementById("diag-transport")
};

// ==============================================================================
// INITIALIZATION
// ==============================================================================
document.addEventListener("DOMContentLoaded", () => {
  initMap();
  initWebSocket();
  initEventHandlers();
  // Fetch initial telemetry via REST to seed dashboard immediately
  fetchLatestTelemetry();
  // Start backup periodic REST polling (ensures real updates if socket drops)
  pollingInterval = setInterval(fetchLatestTelemetry, 2000);
});

// ==============================================================================
// LEAFLET GPS MAP INITIALIZATION
// ==============================================================================
function initMap() {
  const mapElement = document.getElementById("vehicle-map");
  if (!mapElement) return;

  // Initialize world / regional overview view
  leafletMap = L.map("vehicle-map", {
    zoomControl: true,
    attributionControl: true
  }).setView([20.5937, 78.9629], 4); // Initial India/Global overview

  // Add OpenStreetMap tiles
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }).addTo(leafletMap);
}

function updateMapMarker(lat, lng, satellites, speed, safetyState) {
  if (!leafletMap) return;

  // Real GPS Fix acquired
  dom.mapOverlay.classList.add("hidden");

  // Create custom mining truck vehicle icon
  const vehicleIcon = L.divIcon({
    className: "vehicle-marker-wrapper",
    html: `
      <div class="vehicle-marker-icon">
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2">
          <rect x="1" y="3" width="15" height="13"/>
          <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/>
          <circle cx="5.5" cy="18.5" r="2.5"/>
          <circle cx="18.5" cy="18.5" r="2.5"/>
        </svg>
      </div>`,
    iconSize: [36, 36],
    iconAnchor: [18, 18],
    popupAnchor: [0, -20]
  });

  if (!vehicleMarker) {
    vehicleMarker = L.marker([lat, lng], { icon: vehicleIcon }).addTo(leafletMap);
    vehicleMarker.bindPopup(`
      <div style="font-family: var(--font-family); padding: 4px;">
        <strong style="color: #0284c7;">MINING HAUL VEHICLE #01</strong><br>
        State: <b>${safetyState}</b><br>
        Speed: <b>${speed !== null ? speed + ' km/h' : '0 km/h'}</b><br>
        Satellites: <b>${satellites}</b><br>
        Lat: ${lat.toFixed(6)}, Lng: ${lng.toFixed(6)}
      </div>
    `);
  } else {
    vehicleMarker.setLatLng([lat, lng]);
  }

  // Smoothly pan & zoom to real vehicle location
  if (!hasInitialMapPan) {
    leafletMap.flyTo([lat, lng], 16, { animate: true, duration: 1.5 });
    hasInitialMapPan = true;
  } else {
    leafletMap.panTo([lat, lng], { animate: true });
  }
}

function clearMapMarker() {
  dom.mapOverlay.classList.remove("hidden");
  if (vehicleMarker && leafletMap) {
    leafletMap.removeLayer(vehicleMarker);
    vehicleMarker = null;
  }
  hasInitialMapPan = false;
}

// ==============================================================================
// WEBSOCKET COMMUNICATION (FLASK-SOCKETIO)
// ==============================================================================
function initWebSocket() {
  const backendUrl = window.location.origin.startsWith("http")
    ? window.location.origin
    : "http://localhost:5000";

  try {
    socket = io(backendUrl, {
      reconnectionAttempts: 10,
      reconnectionDelay: 1500,
      timeout: 10000
    });

    socket.on("connect", () => {
      dom.diagTransport.textContent = "WebSocket (Real-Time)";
      socket.emit("request_state");
    });

    socket.on("disconnect", () => {
      dom.diagTransport.textContent = "REST Polling Fallback";
    });

    // Real-Time Telemetry Event
    socket.on("telemetry_update", (telemetry) => {
      currentTelemetry = telemetry;
      renderDashboard(telemetry);
    });

    // Live Alert Event
    socket.on("new_alert", (alert) => {
      renderSingleAlert(alert, true);
    });

    socket.on("initial_alerts", (alertsList) => {
      renderAlertsList(alertsList);
    });

    socket.on("alerts_cleared", () => {
      dom.alertsContainer.innerHTML = `
        <div class="alert-empty-state" id="alert-empty-state">
          No critical safety events logged yet. Monitoring hardware sensors...
        </div>`;
    });

  } catch (err) {
    console.warn("WebSocket init failed. Using REST polling fallback.", err);
    dom.diagTransport.textContent = "REST Polling";
  }
}

// ==============================================================================
// REST API FALLBACK & ACTIONS
// ==============================================================================
async function fetchLatestTelemetry() {
  try {
    const res = await fetch("/api/sensor-data");
    if (!res.ok) return;
    const data = await res.json();
    if (data.status === "success" && data.telemetry) {
      currentTelemetry = data.telemetry;
      renderDashboard(currentTelemetry);
      if (data.alerts && data.alerts.length > 0) {
        renderAlertsList(data.alerts);
      }
    }
  } catch (err) {
    // Network offline or server unreachable
  }
}

async function requestSafetyReset() {
  dom.btnResetSafety.disabled = true;
  dom.btnResetSafety.textContent = "PROCESSING UNLOCK...";

  try {
    const res = await fetch("/api/safety/reset", {
      method: "POST",
      headers: { "Content-Type": "application/json" }
    });
    const result = await res.json();

    if (res.ok) {
      alert("SUCCESS: Safety lock has been authorized and released. System restored to NORMAL.");
      fetchLatestTelemetry();
    } else {
      alert("UNLOCK REJECTED: " + (result.message || "Obstacle is still present within safety boundary!"));
    }
  } catch (err) {
    alert("COMMUNICATION ERROR: Unable to deliver safety unlock command to server.");
  } finally {
    dom.btnResetSafety.textContent = "RESET & UNLOCK SAFETY SYSTEM";
    renderDashboard(currentTelemetry);
  }
}

async function sendMotorCmd(command) {
  const cmd = command.toUpperCase();

  if (currentTelemetry.motor_locked || currentTelemetry.manual_control_locked) {
    if (cmd !== "STOP") {
      alert("SAFETY INTERLOCK: Motor is LOCKED! Manual movement is blocked by the safety system.");
      return;
    }
  }

  // Highlight button visually
  highlightDpadButton(cmd);

  // Send via WebSocket for instant real-time response
  if (socket && socket.connected) {
    socket.emit("motor_command", { command: cmd });
  }

  // Also dispatch REST request as fallback
  try {
    const res = await fetch("/api/motor/control", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ command: cmd })
    });
    const result = await res.json();
    if (!res.ok) {
      alert("COMMAND BLOCKED: " + result.message);
    }
  } catch (err) {
    console.error("Motor control error:", err);
  }
}

function highlightDpadButton(cmd) {
  const map = {
    "FORWARD": dom.btnMotorFwd,
    "BACKWARD": dom.btnMotorBwd,
    "LEFT": dom.btnMotorLeft,
    "RIGHT": dom.btnMotorRight,
    "STOP": dom.btnMotorStop
  };
  const btn = map[cmd];
  if (btn) {
    btn.classList.add("active-key");
    setTimeout(() => btn.classList.remove("active-key"), 200);
  }
}

async function clearAlertsHistory() {
  try {
    await fetch("/api/alerts", { method: "DELETE" });
  } catch (err) {
    console.error("Failed to clear alerts:", err);
  }
}

// ==============================================================================
// DASHBOARD RENDERING ENGINE (REAL HARDWARE TELEMETRY ONLY)
// ==============================================================================
function renderDashboard(data) {
  // 1. HEADER CONNECTION BADGES
  if (data.online) {
    dom.dotEsp32.className = "status-dot dot-online";
    dom.valEsp32.textContent = "ONLINE";
  } else {
    dom.dotEsp32.className = "status-dot dot-offline";
    dom.valEsp32.textContent = "OFFLINE";
  }

  if (data.wifi_connected) {
    dom.dotWifi.className = "status-dot dot-online";
    dom.valWifi.textContent = "CONNECTED";
  } else {
    dom.dotWifi.className = "status-dot dot-offline";
    dom.valWifi.textContent = "DISCONNECTED";
  }

  dom.valLastSeen.textContent = data.last_seen_readable || "NEVER";

  // 2. PRIMARY VEHICLE SAFETY STATE BANNER
  renderSafetyStateBanner(data);

  // 3. ULTRASONIC SENSOR CARD
  renderUltrasonicCard(data);

  // 4. ENVIRONMENT SENSOR CARD (DHT)
  renderDHTCard(data);

  // 5. RAIN SENSOR CARD
  renderRainCard(data);

  // 6. MPU6050 DYNAMICS CARD
  renderMPUCard(data);

  // 7. MOTOR DRIVER ACTUATOR CARD
  renderMotorCard(data);

  // 8. BUZZER AUDIBLE ALARM CARD
  renderBuzzerCard(data);

  // 9. GPS GEOLOCATION & MAP
  renderGPSCardAndMap(data);

  // 11. DIAGNOSTICS
  dom.diagIp.textContent = data.ip_address || "Awaiting Connection";
  dom.diagPackets.textContent = data.packet_count || 0;
}

// ------------------------------------------------------------------------------
// SAFETY STATE BANNER LOGIC
// ------------------------------------------------------------------------------
function renderSafetyStateBanner(data) {
  const state = data.safety_state || "NORMAL";
  const isLocked = data.motor_locked;
  const isObstacle = data.obstacle_detected || (data.distance_cm !== null && data.distance_cm <= SAFETY_DISTANCE_THRESHOLD_CM);

  // Clear previous state classes
  dom.safetyBanner.className = "safety-banner";

  if (state === "AUTO_STOP" || isLocked || state === "MOTOR_LOCKED") {
    dom.safetyBanner.classList.add(isLocked ? "state-motor-locked" : "state-auto-stop");
    dom.safetyBadge.textContent = isLocked ? "MOTOR LOCKED" : "AUTO STOP";
    dom.safetyTitle.textContent = isObstacle
      ? "AUTO STOP ACTIVATED: OBSTACLE DETECTED"
      : "VEHICLE SAFETY LOCK ACTIVE";
    dom.safetyDescription.textContent = isObstacle
      ? `Obstacle detected within ${SAFETY_DISTANCE_THRESHOLD_CM} cm safety barrier. Motor instantly stopped and locked. Buzzer active.`
      : "Vehicle motor is locked by safety automation. Operator reset required to resume.";

    // Lock indicator pill
    dom.valMotorLockFlag.textContent = "LOCKED";
    dom.valMotorLockFlag.className = "hazard-pill-val alert-val";

    // Unlock button validation: Only enabled if obstacle is clear!
    if (isObstacle) {
      dom.btnResetSafety.disabled = true;
      dom.resetHelp.textContent = `Clear obstacle (> ${SAFETY_DISTANCE_THRESHOLD_CM} cm) to enable unlock.`;
      dom.resetHelp.style.color = "var(--color-danger)";
    } else {
      dom.btnResetSafety.disabled = false;
      dom.resetHelp.textContent = "Obstacle clear. Click to release motor lock.";
      dom.resetHelp.style.color = "var(--color-safe)";
    }

  } else if (state === "HIGH_RISK") {
    dom.safetyBanner.classList.add("state-high-risk");
    dom.safetyBadge.textContent = "HIGH RISK";
    dom.safetyTitle.textContent = "HIGH RISK SAFETY LEVEL DETECTED";
    dom.safetyDescription.textContent = "Multiple risk factors active: wet haul road surface and/or vehicle instability.";
    dom.valMotorLockFlag.textContent = "UNLOCKED";
    dom.valMotorLockFlag.className = "hazard-pill-val";
    dom.btnResetSafety.disabled = true;
    dom.resetHelp.textContent = "Safety system operating in high-risk vigilance.";
    dom.resetHelp.style.color = "var(--text-muted)";

  } else if (state === "WARNING") {
    dom.safetyBanner.classList.add("state-warning");
    dom.safetyBadge.textContent = "WARNING";
    dom.safetyTitle.textContent = "SAFETY WARNING LEVEL ACTIVE";
    dom.safetyDescription.textContent = "Hazard condition detected (rain or dynamic tilt/vibration). Proceed with caution.";
    dom.valMotorLockFlag.textContent = "UNLOCKED";
    dom.valMotorLockFlag.className = "hazard-pill-val";
    dom.btnResetSafety.disabled = true;
    dom.resetHelp.textContent = "Normal manual reset not required.";
    dom.resetHelp.style.color = "var(--text-muted)";

  } else {
    // NORMAL
    dom.safetyBanner.classList.add("state-normal");
    dom.safetyBadge.textContent = "NORMAL";
    dom.safetyTitle.textContent = "VEHICLE IN SAFE OPERATION";
    dom.safetyDescription.textContent = "All hardware telemetry nominal. No proximity obstacles within 50 cm. All sensors active.";
    dom.valMotorLockFlag.textContent = "UNLOCKED";
    dom.valMotorLockFlag.className = "hazard-pill-val";
    dom.btnResetSafety.disabled = true;
    dom.resetHelp.textContent = "System is currently safe.";
    dom.resetHelp.style.color = "var(--text-muted)";
  }

  // Obstacle pill status
  if (isObstacle) {
    dom.valObstacleFlag.textContent = "DETECTED (<=50cm)";
    dom.valObstacleFlag.className = "hazard-pill-val alert-val";
  } else {
    dom.valObstacleFlag.textContent = "CLEAR";
    dom.valObstacleFlag.className = "hazard-pill-val";
  }
}

// ------------------------------------------------------------------------------
// SENSOR CARD RENDERERS
// ------------------------------------------------------------------------------
function renderUltrasonicCard(data) {
  const dist = data.distance_cm;
  if (dist !== null && dist !== undefined) {
    dom.valDistance.textContent = dist.toFixed(1);
    dom.unitDistance.textContent = "cm";
    const meters = (dist / 100.0).toFixed(2);
    dom.valDistanceMeters.textContent = `${meters} meters`;

    // Visual percentage bar (200 cm nominal max view scale)
    const pct = Math.min(100, Math.max(0, (dist / 200.0) * 100));
    dom.barDistance.style.width = `${pct}%`;

    if (dist <= SAFETY_DISTANCE_THRESHOLD_CM) {
      dom.cardUltrasonic.classList.add("card-danger");
      dom.barDistance.className = "proximity-bar danger-bar";
      dom.statusDistanceMsg.textContent = `OBSTACLE DETECTED! (${dist.toFixed(1)} cm <= 50 cm). AUTO STOP TRIGGERED!`;
      dom.statusDistanceMsg.style.color = "var(--color-danger)";
    } else {
      dom.cardUltrasonic.classList.remove("card-danger");
      dom.barDistance.className = "proximity-bar";
      dom.statusDistanceMsg.textContent = `Path clear (${dist.toFixed(1)} cm > 50 cm barrier).`;
      dom.statusDistanceMsg.style.color = "var(--color-safe)";
    }
  } else {
    dom.valDistance.textContent = "--";
    dom.valDistanceMeters.textContent = "--";
    dom.barDistance.style.width = "0%";
    dom.cardUltrasonic.classList.remove("card-danger");
    dom.statusDistanceMsg.textContent = data.distance_status || "NO DATA / OUT OF RANGE";
    dom.statusDistanceMsg.style.color = "var(--text-muted)";
  }
}

function renderDHTCard(data) {
  if (data.dht_connected && data.temperature !== null && data.humidity !== null) {
    dom.badgeDht.textContent = "CONNECTED";
    dom.badgeDht.className = "card-badge status-badge-safe";
    dom.valTemperature.textContent = data.temperature.toFixed(1);
    dom.valHumidity.textContent = data.humidity.toFixed(1);
    dom.statusDhtMsg.textContent = "Ambient air readings verified.";
    dom.statusDhtMsg.style.color = "var(--text-secondary)";
  } else {
    dom.badgeDht.textContent = "DHT DISCONNECTED";
    dom.badgeDht.className = "card-badge status-badge-neutral";
    dom.valTemperature.textContent = "--";
    dom.valHumidity.textContent = "--";
    dom.statusDhtMsg.textContent = "DHT DISCONNECTED / NO DATA";
    dom.statusDhtMsg.style.color = "var(--color-warning)";
  }
}

function renderRainCard(data) {
  if (data.rain === true) {
    dom.badgeRain.textContent = "ALERT";
    dom.badgeRain.className = "card-badge status-badge-danger";
    dom.valRain.textContent = "RAIN DETECTED";
    dom.valRain.style.color = "var(--color-warning)";
    dom.statusRainMsg.textContent = "Road surface wet. Haul traction hazard warning active.";
    dom.statusRainMsg.style.color = "var(--color-warning)";
  } else if (data.rain_status === "NO RAIN") {
    dom.badgeRain.textContent = "CLEAR";
    dom.badgeRain.className = "card-badge status-badge-safe";
    dom.valRain.textContent = "NO RAIN";
    dom.valRain.style.color = "var(--color-safe)";
    dom.statusRainMsg.textContent = "Road surface dry and nominal.";
    dom.statusRainMsg.style.color = "var(--text-secondary)";
  } else {
    dom.badgeRain.textContent = "NO DATA";
    dom.badgeRain.className = "card-badge status-badge-neutral";
    dom.valRain.textContent = "NO DATA";
    dom.valRain.style.color = "var(--text-muted)";
    dom.statusRainMsg.textContent = "Surface sensor awaiting telemetry.";
    dom.statusRainMsg.style.color = "var(--text-muted)";
  }
}

function renderMPUCard(data) {
  if (data.mpu_connected && data.stability !== "UNKNOWN") {
    dom.valPitch.textContent = data.tilt_pitch !== null ? `${data.tilt_pitch.toFixed(1)}°` : "--";
    dom.valRoll.textContent = data.tilt_roll !== null ? `${data.tilt_roll.toFixed(1)}°` : "--";
    dom.valVibration.textContent = data.vibration_level !== null ? `${data.vibration_level.toFixed(2)} g` : "--";

    dom.badgeMpu.textContent = data.stability;
    if (data.stability === "STABLE") {
      dom.badgeMpu.className = "card-badge status-badge-safe";
      dom.statusMpuMsg.textContent = "Vehicle orientation and vibration stable.";
      dom.statusMpuMsg.style.color = "var(--color-safe)";
    } else {
      dom.badgeMpu.className = "card-badge status-badge-warning";
      dom.statusMpuMsg.textContent = `Instability detected: ${data.stability}!`;
      dom.statusMpuMsg.style.color = "var(--color-warning)";
    }
  } else {
    dom.badgeMpu.textContent = "UNKNOWN";
    dom.badgeMpu.className = "card-badge status-badge-neutral";
    dom.valPitch.textContent = "--";
    dom.valRoll.textContent = "--";
    dom.valVibration.textContent = "--";
    dom.statusMpuMsg.textContent = "MPU6050 DISCONNECTED / UNKNOWN";
    dom.statusMpuMsg.style.color = "var(--text-muted)";
  }
}

function renderMotorCard(data) {
  const motor = data.motor || data.motor_command || "STOPPED";
  const locked = data.motor_locked;

  const allBtns = [
    dom.btnMotorFwd,
    dom.btnMotorBwd,
    dom.btnMotorLeft,
    dom.btnMotorRight,
    dom.btnMotorStop
  ];

  if (locked) {
    dom.badgeMotor.textContent = "LOCKED";
    dom.badgeMotor.className = "card-badge status-badge-danger";
    dom.valMotor.textContent = "MOTOR LOCKED";
    dom.valMotor.style.color = "var(--color-danger)";
    dom.statusMotorMsg.textContent = "MANUAL CONTROL LOCKED by safety system.";
    dom.statusMotorMsg.style.color = "var(--color-danger)";
    allBtns.forEach(b => { if (b) b.disabled = true; });
  } else {
    allBtns.forEach(b => { if (b) b.disabled = false; });

    if (motor === "FORWARD") {
      dom.badgeMotor.textContent = "FORWARD";
      dom.badgeMotor.className = "card-badge status-badge-safe";
      dom.valMotor.textContent = "MOVING FORWARD";
      dom.valMotor.style.color = "var(--color-safe)";
      dom.statusMotorMsg.textContent = "Drive speed active (Forward).";
      dom.statusMotorMsg.style.color = "var(--color-safe)";
    } else if (motor === "BACKWARD") {
      dom.badgeMotor.textContent = "BACKWARD";
      dom.badgeMotor.className = "card-badge status-badge-warning";
      dom.valMotor.textContent = "REVERSING";
      dom.valMotor.style.color = "var(--color-warning)";
      dom.statusMotorMsg.textContent = "Drive speed active (Reverse).";
      dom.statusMotorMsg.style.color = "var(--color-warning)";
    } else if (motor === "LEFT") {
      dom.badgeMotor.textContent = "TURNING LEFT";
      dom.badgeMotor.className = "card-badge status-badge-safe";
      dom.valMotor.textContent = "STEERING LEFT";
      dom.valMotor.style.color = "#38bdf8";
      dom.statusMotorMsg.textContent = "Differential steering Left active.";
      dom.statusMotorMsg.style.color = "#38bdf8";
    } else if (motor === "RIGHT") {
      dom.badgeMotor.textContent = "TURNING RIGHT";
      dom.badgeMotor.className = "card-badge status-badge-safe";
      dom.valMotor.textContent = "STEERING RIGHT";
      dom.valMotor.style.color = "#38bdf8";
      dom.statusMotorMsg.textContent = "Differential steering Right active.";
      dom.statusMotorMsg.style.color = "#38bdf8";
    } else {
      dom.badgeMotor.textContent = "STOPPED";
      dom.badgeMotor.className = "card-badge status-badge-neutral";
      dom.valMotor.textContent = "MOTOR STOPPED";
      dom.valMotor.style.color = "var(--text-secondary)";
      dom.statusMotorMsg.textContent = "Keyboard: [W/A/S/D] or [Arrow Keys] • [Space] Brake";
      dom.statusMotorMsg.style.color = "var(--text-secondary)";
    }
  }
}

function renderBuzzerCard(data) {
  if (data.buzzer === true) {
    dom.badgeBuzzer.textContent = "SOUNDING";
    dom.badgeBuzzer.className = "card-badge status-badge-danger";
    dom.valBuzzer.textContent = "BUZZER ON";
    dom.valBuzzer.style.color = "var(--color-danger)";
    dom.statusBuzzerMsg.textContent = "Audible cab warning active! Danger barrier breached.";
    dom.statusBuzzerMsg.style.color = "var(--color-danger)";
  } else {
    dom.badgeBuzzer.textContent = "OFF";
    dom.badgeBuzzer.className = "card-badge status-badge-safe";
    dom.valBuzzer.textContent = "BUZZER OFF";
    dom.valBuzzer.style.color = "var(--text-secondary)";
    dom.statusBuzzerMsg.textContent = "Local audible warning silent.";
    dom.statusBuzzerMsg.style.color = "var(--text-muted)";
  }
}

function renderGPSCardAndMap(data) {
  const valid = data.gps_valid && data.latitude !== null && data.longitude !== null;

  if (valid) {
    dom.badgeGpsFix.textContent = "3D FIX";
    dom.badgeGpsFix.className = "card-badge status-badge-safe";
    dom.valLat.textContent = data.latitude.toFixed(5);
    dom.valLng.textContent = data.longitude.toFixed(5);
    dom.valSatellites.textContent = data.gps_satellites || 0;
    dom.statusGpsMsg.textContent = "Real GPS fix acquired from NEO-6M.";
    dom.statusGpsMsg.style.color = "var(--color-safe)";

    dom.chipCoordinates.textContent = `LAT: ${data.latitude.toFixed(6)} | LNG: ${data.longitude.toFixed(6)}`;
    dom.chipSatellites.textContent = `SATELLITES: ${data.gps_satellites || 0}`;

    updateMapMarker(data.latitude, data.longitude, data.gps_satellites, data.speed_kmh, data.safety_state);
  } else {
    dom.badgeGpsFix.textContent = "NO FIX";
    dom.badgeGpsFix.className = "card-badge status-badge-neutral";
    dom.valLat.textContent = "--";
    dom.valLng.textContent = "--";
    dom.valSatellites.textContent = data.gps_satellites || 0;
    dom.statusGpsMsg.textContent = "GPS STATUS: NO FIX";
    dom.statusGpsMsg.style.color = "var(--color-warning)";

    dom.chipCoordinates.textContent = "LAT: -- | LNG: --";
    dom.chipSatellites.textContent = `SATELLITES: ${data.gps_satellites || 0}`;

    clearMapMarker();
  }
}

// ------------------------------------------------------------------------------
// LIVE ALERTS LOG RENDERING
// ------------------------------------------------------------------------------
function renderSingleAlert(alert, prepend = true) {
  const emptyState = document.getElementById("alert-empty-state");
  if (emptyState) emptyState.remove();

  const item = document.createElement("div");
  item.className = `alert-item severity-${alert.severity || "INFO"}`;
  item.innerHTML = `
    <div class="alert-time">${alert.timestamp || new Date().toLocaleTimeString()}</div>
    <div class="alert-content">
      <div class="alert-title">${alert.title}</div>
      <div class="alert-desc">${alert.message}</div>
    </div>
  `;

  if (prepend && dom.alertsContainer.firstChild) {
    dom.alertsContainer.insertBefore(item, dom.alertsContainer.firstChild);
  } else {
    dom.alertsContainer.appendChild(item);
  }

  // Cap visible alerts in DOM to 50
  while (dom.alertsContainer.children.length > 50) {
    dom.alertsContainer.removeChild(dom.alertsContainer.lastChild);
  }
}

function renderAlertsList(alerts) {
  if (!alerts || alerts.length === 0) return;
  dom.alertsContainer.innerHTML = "";
  alerts.forEach(a => renderSingleAlert(a, false));
}

// ==============================================================================
// EVENT LISTENERS & KEYBOARD CONTROLS
// ==============================================================================
function initEventHandlers() {
  dom.btnResetSafety.addEventListener("click", () => {
    requestSafetyReset();
  });

  // Global Keyboard Driving Controls: [W/A/S/D], [Arrow Keys], [Space = Brake]
  window.addEventListener("keydown", (e) => {
    // Avoid interfering if user is in an input field
    if (e.target && (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA")) return;

    const key = e.key.toLowerCase();

    if (key === "arrowup" || key === "w") {
      e.preventDefault();
      sendMotorCmd("FORWARD");
    } else if (key === "arrowdown" || key === "s") {
      e.preventDefault();
      sendMotorCmd("BACKWARD");
    } else if (key === "arrowleft" || key === "a") {
      e.preventDefault();
      sendMotorCmd("LEFT");
    } else if (key === "arrowright" || key === "d") {
      e.preventDefault();
      sendMotorCmd("RIGHT");
    } else if (key === " " || key === "spacebar" || key === "escape" || key === "x") {
      e.preventDefault();
      sendMotorCmd("STOP");
    }
  });
}
